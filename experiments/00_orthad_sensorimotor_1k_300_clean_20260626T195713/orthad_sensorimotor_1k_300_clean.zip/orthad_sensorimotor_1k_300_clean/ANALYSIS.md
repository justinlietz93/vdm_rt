# Orthad sensorimotor 1k 300 clean analysis

N=1000, walkers=1200, ticks analyzed=300, segment_ticks=100, curriculum=rich, reafference=True

Input source counts: {"curriculum": 119, "reafference": 181}
Motor event count: 182
Motor by primitive: {"ADMIT": 14, "BOUNDARY": 14, "COUPLING": 4, "CYCLE": 19, "LATCH": 8, "MARK": 14, "PRESSURE": 10, "PROJECTION_LOSS": 5, "REJECT": 15, "REQUEST": 17, "STABLE": 25, "TRACE": 10, "UNSTABLE": 9, "WAIT": 18}
Motor by 100 tick bin: {"0": 60, "100": 60, "200": 62}

Category event rates:
- Q chart: 28/45 = 0.622; top=[('CYCLE', 5), ('WAIT', 4), ('ADMIT', 4), ('STABLE', 4), ('BOUNDARY', 3)]
- B overlap: 20/20 = 1.000; top=[('MARK', 3), ('ADMIT', 3), ('BOUNDARY', 2), ('PRESSURE', 2), ('REQUEST', 2)]
- self consequence: 89/181 = 0.492; top=[('STABLE', 15), ('REQUEST', 10), ('WAIT', 9), ('MARK', 9), ('BOUNDARY', 8)]
- L boundary: 16/20 = 0.800; top=[('STABLE', 3), ('LATCH', 3), ('TRACE', 2), ('CYCLE', 2), ('REJECT', 2)]
- overlap transfer: 16/20 = 0.800; top=[('ADMIT', 2), ('UNSTABLE', 2), ('REQUEST', 2), ('STABLE', 2), ('PRESSURE', 2)]
- L cycle close: 13/14 = 0.929; top=[('TRACE', 2), ('WAIT', 2), ('CYCLE', 2), ('LATCH', 1), ('REJECT', 1)]