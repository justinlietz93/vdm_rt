from __future__ import annotations

import argparse
import json
from pathlib import Path
from vdm_char_actuator import StasisMessageBuffer


def main():
    ap = argparse.ArgumentParser(description="Run written-message actuator channel on JSONL tick rows.")
    ap.add_argument("--input", required=True, help="Input JSONL. Each row may include tick, char_scores, send_score, backspace_score, clear_score, witness_event, intent_text.")
    ap.add_argument("--output", required=True, help="Output JSONL with channel state/events.")
    args = ap.parse_args()

    channel = StasisMessageBuffer()
    inp = Path(args.input)
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)

    with inp.open("r", encoding="utf-8") as f, out.open("w", encoding="utf-8") as g:
        for line_no, line in enumerate(f, start=1):
            line = line.strip()
            if not line:
                continue
            row = json.loads(line)
            result = channel.step(
                tick=int(row.get("tick", line_no - 1)),
                char_scores=row.get("char_scores") or {},
                send_score=float(row.get("send_score", 0.0)),
                backspace_score=float(row.get("backspace_score", 0.0)),
                clear_score=float(row.get("clear_score", 0.0)),
                witness_event=bool(row.get("witness_event", False)),
                intent_text=row.get("intent_text"),
            )
            g.write(result.to_json() + "\n")


if __name__ == "__main__":
    main()
