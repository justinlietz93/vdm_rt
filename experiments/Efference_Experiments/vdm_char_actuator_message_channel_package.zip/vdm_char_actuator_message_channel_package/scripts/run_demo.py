from vdm_char_actuator import StasisMessageBuffer


def score(ch, value=0.9):
    return {ch: value, "x": 0.05}


def main():
    channel = StasisMessageBuffer()
    rows = []

    # Hold H for 3 ticks -> append H
    for t in range(0, 3):
        rows.append(channel.step(tick=t, char_scores=score("H")))
    # release
    rows.append(channel.step(tick=3, char_scores={}))
    # Hold i for 3 ticks -> append i
    for t in range(4, 7):
        rows.append(channel.step(tick=t, char_scores=score("i")))
    # Send held for 2 ticks, with intent witness on the send tick.
    rows.append(channel.step(tick=7, send_score=0.9))
    rows.append(channel.step(tick=8, send_score=0.9, witness_event=True, intent_text="I think I hold attention here."))

    for row in rows:
        if row.events or row.reafferent_text:
            print(row.to_json())


if __name__ == "__main__":
    main()
