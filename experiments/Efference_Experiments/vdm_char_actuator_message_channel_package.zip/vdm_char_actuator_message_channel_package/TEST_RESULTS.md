# Test Results

Unit tests passed locally:

```text
......                                                                   [100%]
6 passed in 0.10s
```

Demo output:

```jsonl
{"appended_char": "H", "buffer_len": 1, "buffer_text": "H", "char_hold_count": 3, "emitted_message": null, "events": [{"char": "H", "kind": "char_append", "score": 0.9, "tick": 2}], "intent_text": null, "reafferent_text": null, "selected_char": "H", "selected_margin": 0.85, "selected_score": 0.9, "send_hold_count": 0, "tick": 2}
{"appended_char": "i", "buffer_len": 2, "buffer_text": "Hi", "char_hold_count": 3, "emitted_message": null, "events": [{"char": "i", "kind": "char_append", "score": 0.9, "tick": 6}], "intent_text": null, "reafferent_text": null, "selected_char": "i", "selected_margin": 0.85, "selected_score": 0.9, "send_hold_count": 0, "tick": 6}
{"appended_char": null, "buffer_len": 0, "buffer_text": "", "char_hold_count": 0, "emitted_message": "Hi", "events": [{"kind": "message_send", "message": "Hi", "tick": 8}], "intent_text": "I think I hold attention here.", "reafferent_text": "I think I hold attention here.\n[written_message]\nHi", "selected_char": null, "selected_margin": 0.0, "selected_score": 0.0, "send_hold_count": 0, "tick": 8}
```
