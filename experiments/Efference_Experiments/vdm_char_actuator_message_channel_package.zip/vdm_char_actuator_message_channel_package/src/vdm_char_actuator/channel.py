from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Any
import json


DEFAULT_ALPHABET = (
    "abcdefghijklmnopqrstuvwxyz"
    "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    "0123456789"
    " .,;:!?'-_()/\\\n"
)


@dataclass(frozen=True)
class CharActuatorConfig:
    """Configuration for the separate written-message actuator channel."""

    alphabet: str = DEFAULT_ALPHABET
    char_threshold: float = 0.72
    char_margin: float = 0.08
    char_hold_ticks: int = 3
    char_release_threshold: float = 0.45
    char_refractory_ticks: int = 1

    send_threshold: float = 0.82
    send_hold_ticks: int = 2
    backspace_threshold: float = 0.84
    backspace_hold_ticks: int = 2
    clear_threshold: float = 0.92
    clear_hold_ticks: int = 3

    max_buffer_chars: int = 512
    message_prefix: str = "[written_message]"
    include_message_prefix: bool = True


@dataclass
class MessageChannelResult:
    tick: int
    selected_char: Optional[str]
    selected_score: float
    selected_margin: float
    char_hold_count: int
    appended_char: Optional[str]
    buffer_text: str
    buffer_len: int
    send_hold_count: int
    emitted_message: Optional[str]
    intent_text: Optional[str]
    reafferent_text: Optional[str]
    events: List[Dict[str, Any]] = field(default_factory=list)

    def to_json(self) -> str:
        return json.dumps(self.__dict__, ensure_ascii=False, sort_keys=True)


class StasisMessageBuffer:
    """
    Separate written-message actuator channel.

    This does not replace the intent witness event. It runs beside it.

    Per tick:
      - The channel reads character actuator scores.
      - A character is appended only after the same character is held above threshold.
      - The buffer remains in stasis until the send intent is held above threshold.
      - If an intent witness and written message occur on the same tick, intent text is returned first.
    """

    def __init__(self, config: Optional[CharActuatorConfig] = None) -> None:
        self.cfg = config or CharActuatorConfig()
        self._alphabet = set(self.cfg.alphabet)
        self._buffer: List[str] = []
        self._held_char: Optional[str] = None
        self._held_count: int = 0
        self._latched_char: Optional[str] = None
        self._refractory: int = 0
        self._send_hold: int = 0
        self._backspace_hold: int = 0
        self._clear_hold: int = 0

    @property
    def buffer_text(self) -> str:
        return "".join(self._buffer)

    def snapshot(self) -> Dict[str, Any]:
        return {
            "buffer_text": self.buffer_text,
            "buffer_len": len(self._buffer),
            "held_char": self._held_char,
            "held_count": self._held_count,
            "latched_char": self._latched_char,
            "refractory": self._refractory,
            "send_hold": self._send_hold,
            "backspace_hold": self._backspace_hold,
            "clear_hold": self._clear_hold,
        }

    @classmethod
    def from_snapshot(cls, snap: Dict[str, Any], config: Optional[CharActuatorConfig] = None) -> "StasisMessageBuffer":
        obj = cls(config=config)
        obj._buffer = list(str(snap.get("buffer_text", "")))[: obj.cfg.max_buffer_chars]
        obj._held_char = snap.get("held_char")
        obj._held_count = int(snap.get("held_count", 0))
        obj._latched_char = snap.get("latched_char")
        obj._refractory = int(snap.get("refractory", 0))
        obj._send_hold = int(snap.get("send_hold", 0))
        obj._backspace_hold = int(snap.get("backspace_hold", 0))
        obj._clear_hold = int(snap.get("clear_hold", 0))
        return obj

    def reset(self) -> None:
        self._buffer.clear()
        self._held_char = None
        self._held_count = 0
        self._latched_char = None
        self._refractory = 0
        self._send_hold = 0
        self._backspace_hold = 0
        self._clear_hold = 0

    def step(
        self,
        *,
        tick: int,
        char_scores: Optional[Dict[str, float]] = None,
        send_score: float = 0.0,
        backspace_score: float = 0.0,
        clear_score: float = 0.0,
        intent_text: Optional[str] = None,
        witness_event: bool = False,
    ) -> MessageChannelResult:
        char_scores = char_scores or {}
        events: List[Dict[str, Any]] = []
        selected_char, selected_score, selected_margin = self._select_char(char_scores)

        appended: Optional[str] = None

        # Release latch when char signal drops or changes decisively.
        if selected_char is None or selected_score < self.cfg.char_release_threshold:
            self._held_char = None
            self._held_count = 0
            self._latched_char = None
        else:
            if selected_char == self._held_char:
                self._held_count += 1
            else:
                self._held_char = selected_char
                self._held_count = 1
                self._latched_char = None

        if self._refractory > 0:
            self._refractory -= 1

        if (
            selected_char is not None
            and self._held_count >= self.cfg.char_hold_ticks
            and self._latched_char != selected_char
            and self._refractory <= 0
            and len(self._buffer) < self.cfg.max_buffer_chars
        ):
            self._buffer.append(selected_char)
            appended = selected_char
            self._latched_char = selected_char
            self._refractory = self.cfg.char_refractory_ticks
            events.append({"kind": "char_append", "tick": tick, "char": selected_char, "score": selected_score})

        # Control intents are also threshold-held, not one-tick impulses.
        if send_score >= self.cfg.send_threshold:
            self._send_hold += 1
        else:
            self._send_hold = 0

        if backspace_score >= self.cfg.backspace_threshold:
            self._backspace_hold += 1
        else:
            self._backspace_hold = 0

        if clear_score >= self.cfg.clear_threshold:
            self._clear_hold += 1
        else:
            self._clear_hold = 0

        if self._backspace_hold == self.cfg.backspace_hold_ticks and self._buffer:
            removed = self._buffer.pop()
            events.append({"kind": "backspace", "tick": tick, "removed": removed})
            self._backspace_hold = 0
            self._latched_char = None

        if self._clear_hold == self.cfg.clear_hold_ticks and self._buffer:
            old = self.buffer_text
            self._buffer.clear()
            events.append({"kind": "clear", "tick": tick, "cleared_text": old})
            self._clear_hold = 0
            self._latched_char = None

        emitted_message: Optional[str] = None
        if self._send_hold == self.cfg.send_hold_ticks and self._buffer:
            emitted_message = self.buffer_text
            self._buffer.clear()
            self._send_hold = 0
            self._held_char = None
            self._held_count = 0
            self._latched_char = None
            events.append({"kind": "message_send", "tick": tick, "message": emitted_message})

        reafferent = self.compose_reafference(intent_text=intent_text if witness_event else None, message=emitted_message)

        return MessageChannelResult(
            tick=tick,
            selected_char=selected_char,
            selected_score=selected_score,
            selected_margin=selected_margin,
            char_hold_count=self._held_count,
            appended_char=appended,
            buffer_text=self.buffer_text,
            buffer_len=len(self._buffer),
            send_hold_count=self._send_hold,
            emitted_message=emitted_message,
            intent_text=intent_text if witness_event else None,
            reafferent_text=reafferent,
            events=events,
        )

    def _select_char(self, char_scores: Dict[str, float]) -> Tuple[Optional[str], float, float]:
        candidates: List[Tuple[str, float]] = []
        for ch, score in char_scores.items():
            if ch in self._alphabet:
                try:
                    candidates.append((ch, float(score)))
                except Exception:
                    continue
        if not candidates:
            return None, 0.0, 0.0
        candidates.sort(key=lambda x: x[1], reverse=True)
        top_ch, top_score = candidates[0]
        second = candidates[1][1] if len(candidates) > 1 else 0.0
        margin = top_score - second
        if top_score >= self.cfg.char_threshold and margin >= self.cfg.char_margin:
            return top_ch, top_score, margin
        return None, top_score, margin

    def compose_reafference(self, *, intent_text: Optional[str], message: Optional[str]) -> Optional[str]:
        parts: List[str] = []
        if intent_text:
            parts.append(str(intent_text))
        if message:
            if self.cfg.include_message_prefix:
                parts.append(f"{self.cfg.message_prefix}\n{message}")
            else:
                parts.append(str(message))
        if not parts:
            return None
        return "\n".join(parts)
