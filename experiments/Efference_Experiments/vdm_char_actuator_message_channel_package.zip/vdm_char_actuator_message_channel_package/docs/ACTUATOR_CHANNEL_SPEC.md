# Written Message Actuator Spec

## Purpose

Add a specific actuator intent/channel that can write individual characters into a stasis buffer and submit the buffer when send pressure crosses threshold.

## Model-side signals

Recommended actuator axes:

```text
WRITE_CHAR_ACTIVE
WRITE_CHAR_SELECT_<char>
WRITE_SEND
WRITE_BACKSPACE
WRITE_CLEAR
```

The runtime should not choose text for the model. It should expose a lawful channel where the model can hold character intent long enough to append a character.

## Threshold law

A character append requires:

```text
top_char_score >= char_threshold
top_char_score - second_char_score >= char_margin
same top_char held for char_hold_ticks
not already latched
```

Send requires:

```text
send_score >= send_threshold for send_hold_ticks
buffer not empty
```

## Simultaneous witness + message

When both normal intent witness and written-message send occur on the same tick:

```text
<intent witness>
[written_message]
<message>
```

This combined text is fed back through the normal UTE reafferent pathway.

## Experimental readout

Key questions this enables:

1. Does the model ever discover and hold a character channel?
2. Does it learn to preserve a buffer across ticks?
3. Does it submit near witness events or independently?
4. Are submitted messages related to the current intent trace?
5. Does receiving its own written message back change the next trace?

## Minimum tests to run in VDM

```text
no_char_channel_control
char_channel_no_reafference
char_channel_reafferent
char_channel_reafferent_shifted
char_channel_reafferent_anti
```

The first milestone is not language. The first milestone is controlled motor use:

```text
held character pressure -> append
buffer retention -> send
send timing -> reafferent effect
```
