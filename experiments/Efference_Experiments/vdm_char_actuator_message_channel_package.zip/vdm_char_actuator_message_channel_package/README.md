# VDM Written Message Actuator Channel

This package prototypes a separate character-level actuator channel for VDM.

It does not replace the intent witness event. It runs beside it.

## Core behavior

Per tick, the channel reads character actuator scores plus control scores:

- `char_scores`: map of candidate characters to actuator pressure
- `send_score`: held send/submit intent
- `backspace_score`: held destructive correction intent
- `clear_score`: held buffer clear intent
- `witness_event`: whether the normal intent witness fired on this tick
- `intent_text`: the normal translated intent witness text, if present

A character is appended only when the same character is held above threshold for multiple ticks. The message buffer then stays in stasis until the model holds send above threshold.

If the model emits a written message on the same tick as an intent witness, the reafferent text is composed as:

```text
<intent witness text>
[written_message]
<message>
```

That preserves the existing intent witness path while allowing written output to follow it through the same reafferent pathway.

## Why this is separate

The intent witness remains the accumulated intention trace readout.

The written-message actuator is a second channel:

```text
intent witness:  "what posture did the model accumulate?"
written message: "what characters did the model hold and submit?"
```

They may fire independently or on the same tick.

## Run the demo

```bash
cd vdm_char_actuator_message_channel_package
PYTHONPATH=src python scripts/run_demo.py
```

Expected final reafferent output includes:

```text
I think I hold attention here.
[written_message]
Hi
```

## Run on JSONL tick rows

```bash
cd vdm_char_actuator_message_channel_package
PYTHONPATH=src python scripts/run_channel_on_jsonl.py \
  --input examples/hi_trace.jsonl \
  --output /tmp/char_channel_output.jsonl
```

Input row schema:

```json
{"tick": 8, "char_scores": {"i": 0.93}, "send_score": 0.91, "witness_event": true, "intent_text": "I think I hold attention here."}
```

## Test

```bash
cd vdm_char_actuator_message_channel_package
PYTHONPATH=src python -m pytest -q
```

## Integration point

At the end of each VDM tick, before reafferent return:

1. Build character actuator scores from the new written-output actuator surface.
2. Call `StasisMessageBuffer.step(...)`.
3. If `result.reafferent_text` is non-empty, feed that text through the same UTE reafferent pathway used by intent traces.
4. Log `result.to_json()` beside the witness/translation event log.

The character channel state must be included in checkpoints. Use `snapshot()` and `from_snapshot()` for 300-tick burst/reload runs.

## Required log fields

Each tick result includes:

- `tick`
- `selected_char`
- `selected_score`
- `selected_margin`
- `char_hold_count`
- `appended_char`
- `buffer_text`
- `buffer_len`
- `send_hold_count`
- `emitted_message`
- `intent_text`
- `reafferent_text`
- `events`

## Guardrails

- No LLM.
- No embeddings.
- No text decoder.
- No random phrase generation.
- No direct replacement of intent witness.
- No character append on a one-tick spike.
- No repeated character without release/re-hold.
- No buffer reset between 300-tick bursts unless the model state itself resets.
