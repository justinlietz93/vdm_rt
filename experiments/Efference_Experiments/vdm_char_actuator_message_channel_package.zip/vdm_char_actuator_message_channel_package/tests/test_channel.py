from vdm_char_actuator import StasisMessageBuffer, CharActuatorConfig


def hold(channel, ch, start=0, n=3):
    out = []
    for t in range(start, start + n):
        out.append(channel.step(tick=t, char_scores={ch: 0.92, "z": 0.01}))
    return out


def test_noise_does_not_append():
    c = StasisMessageBuffer()
    for t in range(10):
        r = c.step(tick=t, char_scores={"a": 0.5, "b": 0.49})
    assert c.buffer_text == ""
    assert r.appended_char is None


def test_append_hi_and_send_after_intent():
    c = StasisMessageBuffer()
    rs = []
    rs += hold(c, "H", 0, 3)
    c.step(tick=3, char_scores={})
    rs += hold(c, "i", 4, 3)
    assert c.buffer_text == "Hi"
    c.step(tick=7, send_score=0.9)
    r = c.step(tick=8, send_score=0.9, witness_event=True, intent_text="I think I hold attention here.")
    assert r.emitted_message == "Hi"
    assert r.reafferent_text == "I think I hold attention here.\n[written_message]\nHi"
    assert c.buffer_text == ""


def test_backspace():
    c = StasisMessageBuffer()
    hold(c, "A", 0, 3)
    c.step(tick=3, char_scores={})
    hold(c, "B", 4, 3)
    assert c.buffer_text == "AB"
    c.step(tick=7, backspace_score=0.9)
    r = c.step(tick=8, backspace_score=0.9)
    assert c.buffer_text == "A"
    assert any(e["kind"] == "backspace" for e in r.events)


def test_repeated_char_requires_release():
    c = StasisMessageBuffer()
    for t in range(10):
        c.step(tick=t, char_scores={"A": 0.95})
    assert c.buffer_text == "A"
    c.step(tick=10, char_scores={})
    for t in range(11, 14):
        c.step(tick=t, char_scores={"A": 0.95})
    assert c.buffer_text == "AA"


def test_empty_send_no_message():
    c = StasisMessageBuffer()
    c.step(tick=1, send_score=0.9)
    r = c.step(tick=2, send_score=0.9, witness_event=True, intent_text="intent")
    assert r.emitted_message is None
    assert r.reafferent_text == "intent"


def test_snapshot_reload_preserves_buffer():
    c = StasisMessageBuffer()
    hold(c, "Q", 0, 3)
    snap = c.snapshot()
    c2 = StasisMessageBuffer.from_snapshot(snap)
    assert c2.buffer_text == "Q"
    c2.step(tick=5, send_score=0.9)
    r = c2.step(tick=6, send_score=0.9)
    assert r.emitted_message == "Q"
