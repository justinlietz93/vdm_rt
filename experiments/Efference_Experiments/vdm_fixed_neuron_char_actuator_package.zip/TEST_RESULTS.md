# Test Results

```text
5 passed
```

Verified:

- Full printable ASCII + newline fixed-neuron map.
- Controls at fixed neurons 0..3.
- Characters assigned to fixed neurons 4..99.
- WRITE_MODE is required to append characters.
- Uppercase, lowercase, digits, punctuation all append through fixed neurons.
- SEND submits buffer and composes after intent witness.
- Character latch prevents unbounded repeated spam from one held neuron.
- BACKSPACE, CLEAR, snapshot, and restore work.

Generated files:

- `docs/fixed_neuron_map.csv`
- `examples/hi_fixed_neuron_output.jsonl`
- `examples/demo_output.jsonl`
