# Aperture control actuator translation

Translated the actuator traces from the aperture control comparison package through the 2048 first-person posture index.

Modes:
- `selector_only`: ordinary selector/motor actuator trace only: active_ops, top_ops, gate/release pressure, top_trace lane fields.
- `aperture_only`: UTE-facing occlusion aperture only: aperture level, active aperture commands, occlusion state. No selector ops, no gate/release, no phase labels.
- `fused`: selector + occlusion aperture together. No phase-label semantic injection.

Outputs:
- `phase_actuator_translation.csv`: one composite translation per run/phase/mode.
- `phase_actuator_topk.csv`: top-k candidates per phase translation.
- `witness_actuator_translation.csv`: interval translations ending at each witness.
- `witness_actuator_topk.csv`: top-k candidates per witness interval.
- `phase_translation_summary_compact.csv`: compact readout.
- `noisy_phase_translation_compact.csv`: noisy/missing-closure only.

Runs processed: closed_loop_1k_300, passive_highres_1k_300_wall60, replay_closed_loop_aperture_1k_300_v2, replay_shift50_1k_300
Phase translations: 36
Witness interval translations: 150
