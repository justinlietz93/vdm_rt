# VDM Aperture Lag Ladder

Corrected aperture timing comparison suite.

Purpose: test whether the same aperture sequence has different effects when it is closed-loop, exact replay, slightly mistimed, heavily mistimed, or randomly reordered while preserving the same aperture distribution.

Core constraints:
- N = 1000
- walkers = 1200
- walker:neuron ratio = 1.2
- ticks = 300
- same input schedule per run
- fresh model state per run
- high-resolution UTE with sensory occlusion actuator

Phases:
- ticks 0-99: stable readable input
- ticks 100-199: noisy / missing-closure input
- ticks 200-299: return stable input

Primary report: reports/RESULTS.md
