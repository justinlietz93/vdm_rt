# Aperture Lag Ladder Results

## Run design

Same input schedule, same seed, fresh 1k model per run:

```text
N = 1000
walkers = 1200
walker:neuron ratio = 1.2
ticks = 300
0-99    stable readable input
100-199 noisy / missing-closure input
200-299 return stable input
```

Runs:

```text
closed_loop        model controls aperture live
passive            high-res UTE, fixed relaxed aperture
lead_shift0        exact replay of closed_loop aperture sequence
lead_shift5        replay shifted by 5 ticks
lead_shift10       replay shifted by 10 ticks
lead_shift25       replay shifted by 25 ticks
lead_shift50       replay shifted by 50 ticks
lead_shift100      replay shifted by 100 ticks
random_matched_v2  same aperture-state distribution, randomly ordered
```

`lead_shift0` matched `closed_loop`, which acts as the deterministic replay check.

## Noisy / missing-closure phase metrics

| run | witnesses | mean gate | interaction ops | revision ops | withdrawal ops | damping ops | selection/hold ops | engaged revision minus withdrawal |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| closed_loop | 9 | 0.75 | 32.41 | 27.25 | 21.90 | 34.54 | 35.23 | 37.76 |
| passive | 7 | 0.75 | 32.78 | 14.96 | 22.69 | 33.50 | 62.27 | 25.05 |
| lead_shift0 | 9 | 0.75 | 32.41 | 27.25 | 21.90 | 34.54 | 35.23 | 37.76 |
| lead_shift5 | 8 | 0.77 | 36.51 | 5.87 | 23.26 | 30.39 | 62.51 | 19.12 |
| lead_shift10 | 9 | 0.77 | 34.28 | 13.64 | 24.37 | 27.26 | 64.12 | 23.55 |
| lead_shift25 | 7 | 0.71 | 36.00 | 6.57 | 19.44 | 36.79 | 48.59 | 23.12 |
| lead_shift50 | 6 | 0.66 | 22.98 | 9.55 | 40.88 | 39.67 | 55.63 | -8.34 |
| lead_shift100 | 6 | 0.57 | 36.14 | 0.81 | 26.42 | 41.29 | 55.30 | 10.53 |
| random_matched_v2 | 8 | 0.65 | 37.49 | 2.79 | 33.93 | 34.45 | 43.75 | 6.35 |

Definitions:

```text
interaction_ops = COMMIT + RELEASE
revision_ops = COMPARE + CORRECT + RETREAT
withdrawal_ops = ABORT + INHIBIT
damping_ops = DAMP
selection_hold_ops = SELECT + HOLD
engaged_revision_minus_withdrawal = interaction_ops + revision_ops - withdrawal_ops
```

## Read

The exact replay reproduced the closed-loop trajectory. That confirms deterministic replay under identical aperture timing.

The strongest result is that closed-loop aperture produced the highest engaged revision profile during noisy / missing-closure input:

```text
closed_loop:
  interaction 32.41
  revision    27.25
  withdrawal  21.90
  engaged     37.76
```

Mistimed aperture did not simply produce more witness spam. It shifted the actuator posture away from revision and toward selection/hold, damping, withdrawal, or low-revision interaction.

The 50-tick mismatch was the most clearly guarded:

```text
lead_shift50:
  interaction 22.98
  revision     9.55
  withdrawal  40.88
  engaged     -8.34
```

The 100-tick and random-matched controls were not clean panic either. They still interacted, but with almost no revision:

```text
lead_shift100 revision:      0.81
random_matched revision:     2.79
closed_loop revision:       27.25
```

So the live closed-loop aperture did not merely increase output. It preserved the model's ability to interact with the disturbed input while also revising/comparing it.

## Immediate interpretation

The result supports the agency/control hypothesis:

```text
closed-loop aperture:
  more open revision and interaction during disturbance

mistimed/replayed aperture:
  less revision, more guarded or mechanically held posture
```

The sensory occlusion / aperture surface looks like more than an input-gain trick. Timing alignment with the model's own actuator state matters.

## Files

- `reports/phase_operation_indices.csv`
- `reports/run_summary_ladder.csv`
- `runs/<run>/tick_rows.csv`
- `runs/<run>/trace_log.jsonl`
- `runs/<run>/ute_aperture_state.jsonl`
- `runs/<run>/utd_events.jsonl`
- `runs/<run>/state_300.h5`
