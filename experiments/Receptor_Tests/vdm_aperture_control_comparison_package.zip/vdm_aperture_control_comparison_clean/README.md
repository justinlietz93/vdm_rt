# VDM aperture control comparison

Closed-loop, passive high-resolution, exact replay, and shifted replay controls for the sensory aperture actuator.

Read `reports/RESULTS.md` first.
