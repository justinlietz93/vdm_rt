#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, json, sys, time, importlib.util, shutil
from pathlib import Path
from types import SimpleNamespace
from collections import Counter

# Reuse the exact sensory occlusion implementation used in the smoke run.
BASE_TOOL = Path('/mnt/data/vdm_sensory_occlusion_probe/tools/run_sensory_occlusion_probe.py')
spec = importlib.util.spec_from_file_location('socclusion', str(BASE_TOOL))
socclusion = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(socclusion)


def load_replay_states(path: Path):
    states=[]
    if not path:
        return states
    with open(path,'r',encoding='utf-8') as f:
        for line in f:
            rec=json.loads(line)
            # Use the exact aperture state that was used before sensing on that tick.
            states.append(rec.get('applied') or rec.get('before') or rec.get('aperture_before') or rec.get('state') or {})
    return states


def run_once(args, mode: str, run_dir: Path, replay_states=None):
    run_dir.mkdir(parents=True, exist_ok=True)
    for name in ['tick_rows.csv','trace_log.jsonl','utd_events.jsonl','ute_aperture_state.jsonl','aperture_events.jsonl','feature_layer_counts.csv','ute_input_stream.jsonl','run_summary.json','phase_summary.csv']:
        p=run_dir/name
        if p.exists(): p.unlink()
    # prepare namespace for reused build
    ns = SimpleNamespace(
        repo=args.repo, run_dir=run_dir, neurons=args.neurons, walkers=args.walkers, k=args.k, hops=args.hops,
        candidates=args.candidates, threshold=args.threshold, lambda_omega=args.lambda_omega,
        domain_modulation=args.domain_modulation, hz=args.hz, seed=args.seed, ticks=args.ticks,
        max_wall_s=args.max_wall_s, stim_amp=args.stim_amp, feature_group_size=args.feature_group_size,
        selector_group_size=args.selector_group_size, release_threshold=args.release_threshold,
        current_op_min=args.current_op_min, current_lane_min=args.current_lane_min,
        selector_decay=args.selector_decay, release_cooldown=args.release_cooldown,
        aperture_group_size=args.aperture_group_size, aperture_current_min=args.aperture_current_min,
        close_hold_ticks=args.close_hold_ticks, bus_capacity=args.bus_capacity, bus_drain=args.bus_drain,
        save_h5=args.save_h5)
    import numpy as np
    np.random.seed(args.seed)
    C,bus,adc,nx_like,eng,world,selector,aperture=socclusion.build(ns, run_dir)
    # If no_close, remove AP_CLOSE as a possible command by raising min beyond possible contacts.
    no_close = (mode == 'no_close')
    # Passive uses relaxed aperture state forever and no aperture-control consequence.
    passive = (mode == 'passive')
    # Replay applies recorded aperture state from a closed-loop run, while still logging what this fresh model would have actuated.
    replay = (mode == 'replay')
    (run_dir/'run_config.json').write_text(json.dumps({**vars(args),'mode':mode,'replay_source':str(args.replay_states or '')},indent=2,default=str),encoding='utf-8')
    (run_dir/'aperture_group_map.json').write_text(json.dumps(aperture.ap_groups,indent=2),encoding='utf-8')
    (run_dir/'selector_group_map.json').write_text(json.dumps({'ops':selector.op_groups,'lanes':selector.lane_groups},indent=2),encoding='utf-8')
    from vdm_rt.runtime.events_adapter import observations_to_events, adc_metrics_to_event
    fields=['tick','phase','atom','stim_count','stim_hash','occlusion_level','aperture_level','aperture_level_name','aperture_width','active_aperture','aperture_commands','obs_count','obs_nodes_unique','active_ops','active_lanes','witnesses','release_lane','release_score','gate_pressure','top_ops','top_lanes','top_trace','tick_s']
    feature_fields=['tick','phase','whole','norm','span','position','shape','pair','char','punct','dark','stim_total','gains']
    phase_counts=Counter(); witness_by_phase=Counter(); aperture_active_counts=Counter(); aperture_command_counts=Counter(); occlusion_ticks=Counter(); aperture_level_counts=Counter(); close_events=[]
    start=time.time(); completed=0; stopped_reason='completed'
    with open(run_dir/'tick_rows.csv','w',newline='',encoding='utf-8') as cf, open(run_dir/'feature_layer_counts.csv','w',newline='',encoding='utf-8') as ff:
        writer=csv.DictWriter(cf,fieldnames=fields); writer.writeheader(); cf.flush()
        fwriter=csv.DictWriter(ff,fieldnames=feature_fields); fwriter.writeheader(); ff.flush()
        with socclusion.ScanFirewall(C):
            for tick in range(args.ticks):
                if time.time()-start > args.max_wall_s:
                    stopped_reason='max_wall_s'; break
                tt=time.perf_counter(); source,phase,atom=world.next_atom(); phase_counts[phase]+=1
                if passive:
                    ap_state_before={'level':0,'level_name':'relaxed','width':3,'occlusion_level':0,'closed':False,'close_counter':0,'gains':aperture.current_gains(),'top_aperture':[]}
                elif replay:
                    if replay_states and tick < len(replay_states):
                        ap_state_before=replay_states[tick]
                    else:
                        ap_state_before=aperture.state_dict()
                else:
                    ap_state_before=aperture.state_dict()
                gains=ap_state_before.get('gains') or aperture.current_gains()
                by_layer=aperture.feature_indices_by_layer(atom,args.neurons,f'ute-sensory-occlusion:{args.seed}',args.feature_group_size)
                stim_all=[]; layer_counts={}
                for layer,idxs in by_layer.items():
                    gain=float(gains.get(layer,0.0)); layer_counts[layer]=len(idxs)
                    if idxs and gain>0:
                        C.stimulate_indices(idxs, amp=args.stim_amp*gain)
                        stim_all.extend(idxs)
                socclusion.append_jsonl(run_dir/'ute_input_stream.jsonl', {'tick':tick,'phase':phase,'atom':atom,'aperture_before':ap_state_before,'layer_counts':layer_counts,'stim_hash':socclusion.sha_list(stim_all),'stim_count':len(set(stim_all))})
                fwriter.writerow({'tick':tick,'phase':phase,**{k:layer_counts.get(k,0) for k in ['whole','norm','span','position','shape','pair','char','punct','dark']},'stim_total':len(set(stim_all)),'gains':json.dumps(gains)}); ff.flush()
                sie2=float(getattr(C,'_last_sie2_valence',0.0) or 0.0); sie_gate=max(0.35,min(1.0,sie2 if sie2>0.0 else 1.0))
                C.step(tick/max(1e-9,args.hz), domain_modulation=args.domain_modulation, sie_drive=sie_gate, use_time_dynamics=True)
                obs=bus.drain(args.bus_drain); adc.update_from(obs); adc_m=adc.get_metrics()
                evs=observations_to_events(obs); evs.append(adc_metrics_to_event(adc_m,tick)); nx_like._emit_step=tick; eng.step(int(max(1,nx_like.dt*1000.0)), evs)
                obs_nodes=[]
                for o in obs:
                    try: obs_nodes.extend([int(x) for x in (getattr(o,'nodes',[]) or [])])
                    except Exception: pass
                sel=selector.observe(tick,obs_nodes,source,atom)
                if passive:
                    ap_update={'active_aperture':[],'aperture_commands':['AP_PASSIVE_FIXED_RELAXED'],'touched_aperture':{},'aperture_state':ap_state_before}
                else:
                    ap_update=aperture.observe_and_update(tick,obs_nodes)
                    if no_close:
                        # Undo closure effects after logging active surface. This run denies sensory occlusion only.
                        if ap_update['aperture_state'].get('occlusion_level',0)>0:
                            aperture.occlusion_level=0
                            aperture.close_counter=0
                        ap_update['aperture_commands']=[c for c in ap_update['aperture_commands'] if not c.startswith('AP_CLOSE')]
                        ap_update['aperture_state']=aperture.state_dict()
                    if replay:
                        # Fresh model can actuate aperture, but applied aperture next tick remains replay file.
                        # Keep monitor state logged, but it is not used for sensing.
                        pass
                for a in ap_update.get('active_aperture',[]): aperture_active_counts[a]+=1
                for c in ap_update.get('aperture_commands',[]): aperture_command_counts[c]+=1
                occlusion_ticks[int(ap_state_before.get('occlusion_level',0))]+=1
                aperture_level_counts[str(ap_state_before.get('level_name','relaxed'))]+=1
                if any(c.startswith('AP_CLOSE') or c.startswith('AP_REOPEN') or c=='AP_OPEN_OR_RELAX' for c in ap_update.get('aperture_commands',[])):
                    ev={'tick':tick,'phase':phase,'atom':atom,'active_aperture':ap_update.get('active_aperture',[]),'aperture_commands':ap_update.get('aperture_commands',[]),'applied_state':ap_state_before,'monitor_state':ap_update.get('aperture_state',{})}
                    close_events.append(ev); socclusion.append_jsonl(run_dir/'aperture_events.jsonl',ev)
                socclusion.append_jsonl(run_dir/'ute_aperture_state.jsonl', {'tick':tick,'phase':phase,'atom':atom,'applied':ap_state_before,'monitor_after':ap_update.get('aperture_state',{}),'active_aperture':ap_update.get('active_aperture',[]),'commands':ap_update.get('aperture_commands',[])})
                for ev in sel['emitted']:
                    ev['phase']=phase; socclusion.append_jsonl(run_dir/'utd_events.jsonl',ev); witness_by_phase[phase]+=1
                rec={'tick':tick,'phase':phase,'atom':atom,'stim_count':len(set(stim_all)),'stim_hash':socclusion.sha_list(stim_all),'occlusion_level':ap_state_before.get('occlusion_level',0),'aperture_level':ap_state_before.get('level',0),'aperture_level_name':ap_state_before.get('level_name','relaxed'),'aperture_width':ap_state_before.get('width',3),'active_aperture':' '.join(ap_update.get('active_aperture',[])),'aperture_commands':' '.join(ap_update.get('aperture_commands',[])),'obs_count':len(obs),'obs_nodes_unique':len(set(obs_nodes)),'active_ops':' '.join(sel['active_ops']),'active_lanes':' '.join(sel['active_lanes']),'witnesses':' '.join(e['witness'] for e in sel['emitted']),'release_lane':sel['release_lane'],'release_score':sel['release_score'],'gate_pressure':sel['gate_pressure'],'top_ops':json.dumps(sel['top_ops']),'top_lanes':json.dumps(sel['top_lanes']),'top_trace':json.dumps(sel['top_trace']),'tick_s':float(time.perf_counter()-tt)}
                writer.writerow(rec); cf.flush(); socclusion.append_jsonl(run_dir/'trace_log.jsonl', {'tick':tick,'phase':phase,'atom':atom,'selector':sel,'aperture':ap_update,'applied_aperture':ap_state_before}); completed=tick+1
    final_h5=None
    if args.save_h5:
        try:
            from vdm_rt.core.memory import save_checkpoint
            final_h5=str(save_checkpoint(str(run_dir), completed, C, fmt='h5', adc=adc))
        except Exception as e:
            final_h5='SAVE_FAILED: '+repr(e)
    phase_summary=[]
    for phase,c in phase_counts.items(): phase_summary.append({'phase':phase,'ticks':c,'witnesses':witness_by_phase[phase],'witness_rate':round(witness_by_phase[phase]/max(1,c),4)})
    with open(run_dir/'phase_summary.csv','w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=['phase','ticks','witnesses','witness_rate']); w.writeheader(); w.writerows(phase_summary)
    summary={'run_dir':str(run_dir),'mode':mode,'neurons':args.neurons,'walkers':args.walkers,'walker_ratio':args.walkers/max(1,args.neurons),'ticks_requested':args.ticks,'ticks_completed':completed,'stopped_reason':stopped_reason,'elapsed_s':round(time.time()-start,3),'mean_tick_s':round((time.time()-start)/max(1,completed),5),'phase_summary':phase_summary,'witness_total':sum(witness_by_phase.values()),'aperture_active_counts':dict(aperture_active_counts),'aperture_command_counts':dict(aperture_command_counts),'occlusion_ticks_by_level':dict(occlusion_ticks),'aperture_level_counts':dict(aperture_level_counts),'close_event_count':len([e for e in close_events if 'AP_CLOSE_CONFIRMED' in e.get('aperture_commands',[])]),'aperture_event_count':len(close_events),'final_aperture_state':aperture.state_dict(),'final_h5':final_h5}
    (run_dir/'run_summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print(json.dumps(summary,indent=2))
    return summary


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--repo',type=Path,required=True); ap.add_argument('--out-dir',type=Path,required=True)
    ap.add_argument('--mode',choices=['closed_loop','passive','replay','no_close'],required=True)
    ap.add_argument('--replay-states',type=Path,default=None)
    ap.add_argument('--neurons',type=int,default=1000); ap.add_argument('--walkers',type=int,default=1200); ap.add_argument('--k',type=int,default=12); ap.add_argument('--hops',type=int,default=2); ap.add_argument('--candidates',type=int,default=64); ap.add_argument('--threshold',type=float,default=0.15); ap.add_argument('--lambda-omega',type=float,default=0.1); ap.add_argument('--domain-modulation',type=float,default=1.15625); ap.add_argument('--hz',type=float,default=10.0); ap.add_argument('--seed',type=int,default=20260627); ap.add_argument('--ticks',type=int,default=300); ap.add_argument('--max-wall-s',type=float,default=180.0)
    ap.add_argument('--stim-amp',type=float,default=0.035); ap.add_argument('--feature-group-size',type=int,default=1)
    ap.add_argument('--selector-group-size',type=int,default=8); ap.add_argument('--release-threshold',type=float,default=0.8); ap.add_argument('--current-op-min',type=int,default=2); ap.add_argument('--current-lane-min',type=int,default=2); ap.add_argument('--selector-decay',type=float,default=0.965); ap.add_argument('--release-cooldown',type=int,default=8)
    ap.add_argument('--aperture-group-size',type=int,default=10); ap.add_argument('--aperture-current-min',type=int,default=1); ap.add_argument('--close-hold-ticks',type=int,default=2)
    ap.add_argument('--bus-capacity',type=int,default=65536); ap.add_argument('--bus-drain',type=int,default=4096); ap.add_argument('--save-h5',action='store_true')
    args=ap.parse_args()
    replay_states=load_replay_states(args.replay_states) if args.replay_states else None
    run_once(args,args.mode,args.out_dir,args.replay_states and replay_states)
if __name__=='__main__': raise SystemExit(main())
