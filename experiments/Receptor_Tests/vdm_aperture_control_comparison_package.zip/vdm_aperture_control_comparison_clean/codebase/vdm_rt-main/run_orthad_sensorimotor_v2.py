#!/usr/bin/env python3
"""
VDM-RT Orthad legal-curriculum segmented resume runner.

Purpose
-------
Run the original VDM engine on a legal lifted Orthad grammar stream:

    one operator atom per tick -> receptor transduction -> native VDM step
    -> void-walker announcements -> fixed output neuron groups -> motor events

This is not ML training. It is a curriculum/environment stream: lawful patterns
are presented over time and the run logs what the engine emits through a fixed
actuator manifold.

Hard rules
----------
- Do not patch engine files.
- Do not send illegal/probe labels.
- Do not scan/reduce the graph during ticks.
- Do not classify the run while it is running.
- The output basis is fixed device-owned neuron groups.
- Output fires only from walker-announced contact with those groups.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.util
import json
import random
import shutil
import sys
import time
from collections import Counter, defaultdict, deque
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Dict, Iterable, Iterator, List, Optional, Sequence, Tuple


def bootstrap_vdm(repo: Path) -> None:
    repo = repo.resolve()
    init_py = repo / "__init__.py"
    if not init_py.exists():
        raise SystemExit(f"Could not find __init__.py in repo root: {repo}")
    if str(repo.parent) not in sys.path:
        sys.path.insert(0, str(repo.parent))
    if "vdm_rt" not in sys.modules:
        spec = importlib.util.spec_from_file_location(
            "vdm_rt",
            str(init_py),
            submodule_search_locations=[str(repo)],
        )
        if spec is None or spec.loader is None:
            raise SystemExit("Could not create vdm_rt import spec")
        mod = importlib.util.module_from_spec(spec)
        sys.modules["vdm_rt"] = mod
        spec.loader.exec_module(mod)


def _u64(s: str) -> int:
    h = hashlib.blake2b(s.encode("utf-8"), digest_size=8).digest()
    return int.from_bytes(h, "little", signed=False)


def deterministic_group(label: str, n: int, size: int, salt: str) -> List[int]:
    out: List[int] = []
    seen = set()
    j = 0
    while len(out) < max(1, int(size)):
        idx = int(_u64(f"{salt}|{label}|{j}") % max(1, int(n)))
        j += 1
        if idx in seen:
            continue
        seen.add(idx)
        out.append(idx)
    return out


def atom_to_indices(atom: str, n: int, group_size: int, max_units: int, salt: str) -> List[int]:
    """Ordered/repetition-preserving receptor transduction for one grammar atom."""
    atom = str(atom).strip()
    if not atom:
        return []
    toks = atom.split()
    labels: List[str] = [f"atom:{atom}"]
    for pos, tok in enumerate(toks[: int(max_units)]):
        labels.append(f"pos:{pos}:tok:{tok}")
        labels.append(f"tok:{tok}")
    idxs: List[int] = []
    seen = set()
    for lab in labels:
        for idx in deterministic_group(lab, n, group_size, salt):
            if idx not in seen:
                seen.add(idx)
                idxs.append(idx)
    return idxs


LEGAL_BASIC = [
    "Q chart A",
    "B overlap AB",
    "L boundary AB",
    "Q chart B",
    "overlap transfer AB BC",
    "L cycle close",
]

LEGAL_REWRITE = [
    "Q chart A",
    "B overlap AB",
    "Q chart B",
    "L boundary AB",
    "overlap transfer AB BC",
    "L cycle close",
]

LEGAL_THREE_CHART_LOOP = [
    "Q chart A",
    "B overlap AB",
    "L boundary AB",
    "Q chart B",
    "overlap transfer AB BC",
    "B overlap BC",
    "L boundary BC",
    "Q chart C",
    "overlap transfer BC CA",
    "B overlap CA",
    "L boundary CA",
    "overlap transfer CA AB",
    "L cycle close",
]

LEGAL_LATCH_RICH = [
    "Q chart A",
    "B overlap AB",
    "L boundary AB",
    "Q chart B",
    "B overlap BC",
    "L boundary BC",
    "Q chart C",
    "overlap transfer AB BC",
    "overlap transfer BC CA",
    "L cycle close",
]

BUILTIN_STREAMS = {
    "basic": [LEGAL_BASIC],
    "rewrite_mix": [LEGAL_BASIC, LEGAL_REWRITE],
    "three_chart": [LEGAL_BASIC, LEGAL_REWRITE, LEGAL_THREE_CHART_LOOP],
    "rich": [LEGAL_BASIC, LEGAL_REWRITE, LEGAL_THREE_CHART_LOOP, LEGAL_LATCH_RICH],
}


class CurriculumWorld:
    def __init__(self, curriculum: str, stream_file: Optional[Path], seed: int, reafference: bool) -> None:
        self.rng = random.Random(int(seed))
        self.reafference_enabled = bool(reafference)
        self.reafference_queue: deque[str] = deque(maxlen=256)
        if stream_file is not None:
            atoms = [ln.strip() for ln in Path(stream_file).read_text(encoding="utf-8").splitlines() if ln.strip() and not ln.strip().startswith("#")]
            if not atoms:
                raise SystemExit(f"stream file has no atoms: {stream_file}")
            self.cycles = [atoms]
            self.name = f"file:{stream_file}"
        else:
            self.cycles = [list(cyc) for cyc in BUILTIN_STREAMS[str(curriculum)]]
            self.name = str(curriculum)
        self._tick = 0

    def push_reafference(self, primitive: str) -> None:
        if self.reafference_enabled:
            primitive = str(primitive).strip().upper()
            if primitive:
                self.reafference_queue.append(f"motor feedback {primitive}")

    def next_atom(self) -> Tuple[str, str, int, int]:
        """Return (source, atom, cycle_index, atom_index)."""
        if self.reafference_queue:
            atom = self.reafference_queue.popleft()
            self._tick += 1
            return "reafference", atom, -1, -1
        cycle_idx = self._tick % len(self.cycles)
        cycle = self.cycles[cycle_idx]
        atom_idx = (self._tick // len(self.cycles)) % len(cycle)
        atom = cycle[atom_idx]
        self._tick += 1
        return "curriculum", atom, int(cycle_idx), int(atom_idx)


ACTUATOR_PRIMITIVES = [
    "WAIT",
    "MARK",
    "TRACE",
    "BOUNDARY",
    "CYCLE",
    "LATCH",
    "PRESSURE",
    "STABLE",
    "UNSTABLE",
    "REQUEST",
    "REJECT",
    "ADMIT",
    "PROJECTION_LOSS",
    "COUPLING",
]


class FixedGroupActuator:
    """
    Fixed output-device neuron groups.

    No calibration phase. No legal/illegal probe gate. No scan.
    Energy accumulates only when void-walker announcements include group nodes.
    A primitive fires when its group contact energy crosses a fixed threshold.
    """
    def __init__(self, n: int, group_size: int, salt: str, threshold: float, decay: float, cooldown: int, run_dir: Path) -> None:
        self.n = int(n)
        self.threshold = float(threshold)
        self.decay = float(decay)
        self.cooldown = int(max(0, cooldown))
        self.run_dir = Path(run_dir)
        self.groups: Dict[str, List[int]] = {p: deterministic_group(f"actuator:{p}", self.n, group_size, salt) for p in ACTUATOR_PRIMITIVES}
        self.node_to_prims: Dict[int, List[str]] = defaultdict(list)
        for prim, nodes in self.groups.items():
            for node in nodes:
                self.node_to_prims[int(node)].append(prim)
        self.energy: Dict[str, float] = {p: 0.0 for p in ACTUATOR_PRIMITIVES}
        self.last_fire: Dict[str, int] = {p: -10**12 for p in ACTUATOR_PRIMITIVES}
        with open(self.run_dir / "output_group_map.json", "w", encoding="utf-8") as f:
            json.dump(self.groups, f, indent=2)

    def observe_nodes(self, tick: int, nodes: Iterable[int], source: str, weight: float = 1.0) -> List[str]:
        for p in ACTUATOR_PRIMITIVES:
            self.energy[p] *= self.decay

        touched = Counter()
        for node in nodes:
            for prim in self.node_to_prims.get(int(node), []):
                touched[prim] += 1

        for prim, count in touched.items():
            self.energy[prim] += float(weight) * float(count)

        fired: List[str] = []
        for prim in ACTUATOR_PRIMITIVES:
            if self.energy[prim] >= self.threshold and (int(tick) - self.last_fire[prim]) >= self.cooldown:
                self.last_fire[prim] = int(tick)
                fired.append(prim)
                self._write_event(tick, prim, source, self.energy[prim], int(touched.get(prim, 0)))
                self.energy[prim] *= 0.25
        return fired

    def _write_event(self, tick: int, primitive: str, source: str, energy: float, contact_count: int) -> None:
        rec = {
            "tick": int(tick),
            "primitive": str(primitive),
            "source": str(source),
            "energy": float(energy),
            "threshold": float(self.threshold),
            "contact_count": int(contact_count),
        }
        with open(self.run_dir / "motor_events.jsonl", "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")


class ScanFirewall:
    def __init__(self, connectome: Any):
        self.connectome = connectome
        self.originals: Dict[str, Any] = {}
        self.forbidden = [
            "active_edge_count",
            "connected_components",
            "cyclomatic_complexity",
            "snapshot_graph",
            "connectome_entropy",
        ]

    def __enter__(self):
        for name in self.forbidden:
            if hasattr(self.connectome, name):
                self.originals[name] = getattr(self.connectome, name)

                def _boom(*_a, _name=name, **_kw):
                    raise RuntimeError(f"SCAN_FIREWALL: forbidden graph scan called: {_name}")

                setattr(self.connectome, name, _boom)
        return self

    def __exit__(self, exc_type, exc, tb):
        for name, fn in self.originals.items():
            setattr(self.connectome, name, fn)
        return False



def _json_default(x):
    try:
        import numpy as np
        if isinstance(x, (np.integer,)):
            return int(x)
        if isinstance(x, (np.floating,)):
            return float(x)
        if isinstance(x, (np.ndarray,)):
            return x.tolist()
    except Exception:
        pass
    raise TypeError(f"not JSON serializable: {type(x).__name__}")



def _np_rng_to_jsonable(state):
    import numpy as np
    name, keys, pos, has_gauss, cached_gaussian = state
    return {
        "name": str(name),
        "keys": np.asarray(keys, dtype=np.uint32).tolist(),
        "pos": int(pos),
        "has_gauss": int(has_gauss),
        "cached_gaussian": float(cached_gaussian),
    }


def _np_rng_from_jsonable(obj):
    import numpy as np
    return (
        str(obj["name"]),
        np.asarray(obj["keys"], dtype=np.uint32),
        int(obj["pos"]),
        int(obj["has_gauss"]),
        float(obj["cached_gaussian"]),
    )


def _sha_arr(a):
    import hashlib
    import numpy as np
    aa = np.asarray(a)
    return hashlib.sha256(aa.tobytes() + str(aa.shape).encode() + str(aa.dtype).encode()).hexdigest()


def _sha_jsonable(x):
    import hashlib
    return hashlib.sha256(json.dumps(x, sort_keys=True, default=str).encode("utf-8")).hexdigest()


def _adj_signature(adj):
    import hashlib
    import numpy as np
    h = hashlib.sha256()
    for row in adj:
        a = np.asarray(row, dtype=np.int32)
        h.update(a.tobytes())
        h.update(b"|")
    return h.hexdigest()



def _canonical_adc_dict(x):
    if not isinstance(x, dict):
        return {}
    y = json.loads(json.dumps(x, sort_keys=True, default=str))
    try:
        y["territories"] = sorted(y.get("territories", []), key=lambda r: (r.get("key", ["", 0])[0], int(r.get("key", ["", 0])[1]), int(r.get("id", 0))))
    except Exception:
        pass
    try:
        y["boundaries"] = sorted(y.get("boundaries", []), key=lambda r: (int(r.get("a", 0)), int(r.get("b", 0))))
    except Exception:
        pass
    try:
        y["frontier_counter"] = sorted(y.get("frontier_counter", []), key=lambda r: (r.get("key", ["", 0])[0], int(r.get("key", ["", 0])[1]), int(r.get("count", 0))))
    except Exception:
        pass
    return y



def _adc_load_exact(adc, state):
    if adc is None or not isinstance(state, dict):
        return
    from vdm_rt.core.adc import Territory, Boundary, _EWMA
    terr_d = {}
    max_id = 0
    for t in state.get("territories", []) or []:
        dom, cov = t.get("key", ["", 0])
        tid = int(t.get("id", 0))
        max_id = max(max_id, tid)
        def ew(d, default_alpha):
            d = d or {}
            return _EWMA(alpha=float(d.get("alpha", default_alpha)), mean=float(d.get("mean", 0.0)), var=float(d.get("var", 0.0)), init=bool(d.get("init", False)))
        terr_d[(str(dom), int(cov))] = Territory(
            key=(str(dom), int(cov)),
            id=tid,
            mass=float(t.get("mass", 0.0)),
            conf=float(t.get("conf", 0.0)),
            ttl=int(t.get("ttl", 0)),
            w_stats=ew(t.get("w_stats", {}), 0.15),
            s_stats=ew(t.get("s_stats", {}), 0.15),
        )
    bnd_d = {}
    for b in state.get("boundaries", []) or []:
        a = int(b.get("a", 0)); c = int(b.get("b", 0))
        def ew(d, default_alpha):
            d = d or {}
            return _EWMA(alpha=float(d.get("alpha", default_alpha)), mean=float(d.get("mean", 0.0)), var=float(d.get("var", 0.0)), init=bool(d.get("init", False)))
        bnd_d[(min(a,c), max(a,c))] = Boundary(
            a=min(a,c), b=max(a,c), ttl=int(b.get("ttl", 0)),
            cut_stats=ew(b.get("cut_stats", {}), 0.2),
            churn=ew(b.get("churn", {}), 0.2),
        )
    fcnt = {}
    for fc in state.get("frontier_counter", []) or []:
        dom, cov = fc.get("key", ["", 0])
        fcnt[(str(dom), int(cov))] = int(fc.get("count", 0))
    adc._territories = terr_d
    adc._boundaries = bnd_d
    adc._frontier_counter = fcnt
    adc._id_seq = int(state.get("id_seq", max_id + 1))


def state_signature(C: Any, adc: Any, world: CurriculumWorld, motor: FixedGroupActuator) -> Dict[str, Any]:
    from vdm_rt.core.memory.engram_io import _adc_to_dict
    sig = {
        "W": _sha_arr(getattr(C, "W", [])),
        "adj": _adj_signature(getattr(C, "adj", [])),
        "connectome_rng": _sha_jsonable(getattr(C, "rng").bit_generator.state),
        "numpy_global_rng": _sha_jsonable(_np_rng_to_jsonable(__import__("numpy").random.get_state())),
        "stim": _sha_arr(getattr(C, "_stim", [])),
        "connectome_tick": int(getattr(C, "_tick", 0)),
        "findings": _sha_jsonable(getattr(C, "findings", {}) or {}),
        "adc": _sha_jsonable(_canonical_adc_dict(_adc_to_dict(adc))),
        "adc_cycle_events": int(getattr(adc, "_cycle_events", 0)),
        "world_tick": int(getattr(world, "_tick", 0)),
        "world_queue": list(getattr(world, "reafference_queue", [])),
        "motor_energy": {str(k): float(v) for k, v in getattr(motor, "energy", {}).items()},
        "motor_last_fire": {str(k): int(v) for k, v in getattr(motor, "last_fire", {}).items()},
    }
    for k in ["_last_sie2_reward", "_last_sie2_valence", "_edges_active", "_vertices_active", "_last_edges_active", "_last_vertices_active", "_frag_components_lb", "_frag_dirty_since", "_last_pruned_count", "_last_bridged_count"]:
        v = getattr(C, k, None)
        try:
            if v is None:
                sig[k] = None
            elif isinstance(v, float):
                sig[k] = float(v)
            else:
                sig[k] = int(v)
        except Exception:
            sig[k] = str(v)
    dsu = getattr(C, "_frag_dsu", None)
    if dsu is not None:
        sig["frag_parent"] = _sha_arr(getattr(dsu, "parent", []))
        sig["frag_rank"] = _sha_arr(getattr(dsu, "rank", []))
        sig["frag_size"] = _sha_arr(getattr(dsu, "size", []))
        sig["frag_components"] = int(getattr(dsu, "components", 0))
    sie2 = getattr(C, "_sie2", None)
    if sie2 is not None:
        sig["sie2_mu"] = _sha_arr(getattr(sie2, "mu", []))
        sig["sie2_var"] = _sha_arr(getattr(sie2, "var", []))
        sig["sie2_prev_W"] = _sha_arr(getattr(sie2, "prev_W", []))
        sig["sie2_valence"] = float(getattr(sie2, "valence", 0.0))
    return sig


def append_runner_state_to_h5(path: str, C: Any, adc: Any, world: CurriculumWorld, motor: FixedGroupActuator, tick: int, args: Any) -> None:
    """Append harness-level state into the H5 without modifying the engine checkpoint code."""
    try:
        import h5py
        import numpy as np
        from vdm_rt.core.primitives.dsu import DSU
        from vdm_rt.core.memory.engram_io import _adc_to_dict
    except Exception as e:
        raise RuntimeError(f"Cannot append extended H5 state: {e}")

    with h5py.File(path, "a") as f:
        if "orthad_runner" in f:
            del f["orthad_runner"]
        g = f.create_group("orthad_runner")
        g.attrs["tick"] = int(tick)
        g.attrs["curriculum"] = str(world.name)
        g.attrs["seed"] = int(args.seed)
        g.attrs["schema"] = "orthad_curriculum_resume_v1"
        g.attrs["reafference"] = bool(args.reafference)
        g.attrs["motor_threshold"] = float(args.motor_threshold)
        g.attrs["motor_decay"] = float(args.motor_decay)
        g.attrs["motor_cooldown"] = int(args.motor_cooldown)
        g.attrs["motor_group_size"] = int(args.motor_group_size)
        g.attrs["stim_group_size"] = int(args.stim_group_size)
        g.attrs["stim_max_units"] = int(args.stim_max_units)
        g.attrs["stim_amp"] = float(args.stim_amp)
        try:
            g.create_dataset("rng_state_json", data=json.dumps(C.rng.bit_generator.state, default=_json_default), dtype=h5py.string_dtype("utf-8"))
        except Exception:
            pass
        try:
            g.create_dataset("stim", data=np.asarray(getattr(C, "_stim", []), dtype=np.float32), compression="gzip")
        except Exception:
            pass
        scalars = {
            "connectome_tick": int(getattr(C, "_tick", 0)),
            "last_sie2_reward": float(getattr(C, "_last_sie2_reward", 0.0) or 0.0),
            "last_sie2_valence": float(getattr(C, "_last_sie2_valence", 0.0) or 0.0),
            "edges_active": int(getattr(C, "_edges_active", 0) or 0),
            "vertices_active": int(getattr(C, "_vertices_active", 0) or 0),
            "last_edges_active": int(getattr(C, "_last_edges_active", 0) or 0),
            "last_vertices_active": int(getattr(C, "_last_vertices_active", 0) or 0),
            "frag_components_lb": int(getattr(C, "_frag_components_lb", getattr(C, "N", 0)) or 0),
            "last_pruned_count": int(getattr(C, "_last_pruned_count", 0) or 0),
            "last_bridged_count": int(getattr(C, "_last_bridged_count", 0) or 0),
        }
        scalars["frag_dirty_since"] = getattr(C, "_frag_dirty_since", None)
        g.create_dataset("scalars_json", data=json.dumps(scalars), dtype=h5py.string_dtype("utf-8"))
        g.create_dataset("numpy_global_rng_json", data=json.dumps(_np_rng_to_jsonable(np.random.get_state())), dtype=h5py.string_dtype("utf-8"))
        g.attrs["adc_cycle_events"] = int(getattr(adc, "_cycle_events", 0))
        try:
            g.create_dataset("adc_exact_json", data=json.dumps(_adc_to_dict(adc), default=_json_default), dtype=h5py.string_dtype("utf-8"))
        except Exception:
            pass
        try:
            g.create_dataset("findings_json", data=json.dumps(getattr(C, "findings", {}) or {}, default=_json_default), dtype=h5py.string_dtype("utf-8"))
        except Exception:
            pass
        try:
            fd = getattr(C, "_frag_dsu", None)
            if fd is not None:
                dg = g.create_group("frag_dsu")
                dg.create_dataset("parent", data=np.asarray(fd.parent, dtype=np.int32), compression="gzip")
                dg.create_dataset("rank", data=np.asarray(fd.rank, dtype=np.int8), compression="gzip")
                dg.create_dataset("size", data=np.asarray(fd.size, dtype=np.int32), compression="gzip")
                dg.attrs["components"] = int(fd.components)
        except Exception:
            pass
        try:
            sie2 = getattr(C, "_sie2", None)
            if sie2 is not None:
                sg = g.create_group("sie2")
                sg.create_dataset("mu", data=np.asarray(sie2.mu, dtype=np.float32), compression="gzip")
                sg.create_dataset("var", data=np.asarray(sie2.var, dtype=np.float32), compression="gzip")
                sg.create_dataset("prev_W", data=np.asarray(sie2.prev_W, dtype=np.float32), compression="gzip")
                sg.attrs["valence"] = float(sie2.valence)
        except Exception:
            pass
        world_state = {
            "tick": int(getattr(world, "_tick", 0)),
            "name": str(getattr(world, "name", "")),
            "reafference_queue": list(getattr(world, "reafference_queue", [])),
        }
        g.create_dataset("world_json", data=json.dumps(world_state), dtype=h5py.string_dtype("utf-8"))
        motor_state = {
            "groups": getattr(motor, "groups", {}),
            "energy": getattr(motor, "energy", {}),
            "last_fire": getattr(motor, "last_fire", {}),
        }
        g.create_dataset("motor_json", data=json.dumps(motor_state, default=_json_default), dtype=h5py.string_dtype("utf-8"))


def load_runner_state_from_h5(path: str, C: Any, adc: Any, world: CurriculumWorld, motor: FixedGroupActuator) -> int:
    """Load H5 engine state plus harness-level state. Returns saved absolute tick."""
    try:
        import h5py
        import numpy as np
        from vdm_rt.core.primitives.dsu import DSU
        from vdm_rt.core.memory.engram_io import _adc_to_dict
        from vdm_rt.core.sie_v2 import SIECfg, SIEState
    except Exception as e:
        raise RuntimeError(f"Cannot load extended H5 state: {e}")

    saved_tick = 0
    with h5py.File(path, "r") as f:
        if "orthad_runner" not in f:
            return saved_tick
        g = f["orthad_runner"]
        saved_tick = int(g.attrs.get("tick", 0))
        try:
            raw = g["rng_state_json"][()]
            if isinstance(raw, bytes):
                raw = raw.decode("utf-8")
            C.rng.bit_generator.state = json.loads(raw)
        except Exception:
            pass
        try:
            if "stim" in g:
                C._stim = g["stim"][...].astype(np.float32, copy=False)
        except Exception:
            pass
        try:
            raw = g["scalars_json"][()]
            if isinstance(raw, bytes):
                raw = raw.decode("utf-8")
            scalars = json.loads(raw)
            C._tick = int(scalars.get("connectome_tick", getattr(C, "_tick", 0)))
            C._last_sie2_reward = float(scalars.get("last_sie2_reward", 0.0))
            C._last_sie2_valence = float(scalars.get("last_sie2_valence", 0.0))
            C._edges_active = int(scalars.get("edges_active", 0))
            C._vertices_active = int(scalars.get("vertices_active", 0))
            C._last_edges_active = int(scalars.get("last_edges_active", 0))
            C._last_vertices_active = int(scalars.get("last_vertices_active", 0))
            C._frag_components_lb = int(scalars.get("frag_components_lb", getattr(C, "N", 0)))
            C._last_pruned_count = int(scalars.get("last_pruned_count", 0))
            C._last_bridged_count = int(scalars.get("last_bridged_count", 0))
            C._frag_dirty_since = scalars.get("frag_dirty_since", None)
        except Exception:
            pass
        try:
            raw = g.get("numpy_global_rng_json", None)
            if raw is not None:
                rawv = raw[()]
                if isinstance(rawv, bytes):
                    rawv = rawv.decode("utf-8")
                np.random.set_state(_np_rng_from_jsonable(json.loads(rawv)))
        except Exception:
            pass
        try:
            if "findings_json" in g:
                rawf = g["findings_json"][()]
                if isinstance(rawf, bytes):
                    rawf = rawf.decode("utf-8")
                C.findings = json.loads(rawf)
        except Exception:
            pass
        try:
            if "adc_exact_json" in g:
                rawa = g["adc_exact_json"][()]
                if isinstance(rawa, bytes):
                    rawa = rawa.decode("utf-8")
                _adc_load_exact(adc, json.loads(rawa))
        except Exception:
            pass
        try:
            setattr(adc, "_cycle_events", int(g.attrs.get("adc_cycle_events", getattr(adc, "_cycle_events", 0))))
        except Exception:
            pass
        try:
            if "frag_dsu" in g:
                dg = g["frag_dsu"]
                dsu = DSU(int(C.N))
                dsu.parent = dg["parent"][...].astype(np.int32, copy=False)
                dsu.rank = dg["rank"][...].astype(np.int8, copy=False)
                dsu.size = dg["size"][...].astype(np.int32, copy=False)
                dsu.components = int(dg.attrs.get("components", int(C.N)))
                C._frag_dsu = dsu
        except Exception:
            pass
        try:
            if "sie2" in g:
                sg = g["sie2"]
                s = SIEState(int(C.N), SIECfg())
                s.mu = sg["mu"][...].astype(np.float32, copy=False)
                s.var = sg["var"][...].astype(np.float32, copy=False)
                s.prev_W = sg["prev_W"][...].astype(np.float32, copy=False)
                s.valence = float(sg.attrs.get("valence", 0.0))
                C._sie2 = s
        except Exception:
            pass
        try:
            raw = g["world_json"][()]
            if isinstance(raw, bytes):
                raw = raw.decode("utf-8")
            ws = json.loads(raw)
            world._tick = int(ws.get("tick", saved_tick))
            world.reafference_queue.clear()
            for item in ws.get("reafference_queue", []):
                world.reafference_queue.append(str(item))
        except Exception:
            world._tick = saved_tick
        try:
            raw = g["motor_json"][()]
            if isinstance(raw, bytes):
                raw = raw.decode("utf-8")
            ms = json.loads(raw)
            if isinstance(ms.get("energy"), dict):
                motor.energy.update({str(k): float(v) for k, v in ms["energy"].items()})
            if isinstance(ms.get("last_fire"), dict):
                motor.last_fire.update({str(k): int(v) for k, v in ms["last_fire"].items()})
        except Exception:
            pass
    return saved_tick


def build_runtime(args: Any, run_dir: Path, bootstrap_done: bool = True):
    from vdm_rt.core.sparse_connectome import SparseConnectome
    from vdm_rt.core.bus import AnnounceBus
    from vdm_rt.core.adc import ADC
    from vdm_rt.core.engine import CoreEngine

    walkers = int(args.walkers) if args.walkers is not None else int(round(1.2 * int(args.neurons)))
    C = SparseConnectome(
        N=int(args.neurons),
        k=int(args.k),
        seed=int(args.seed),
        threshold=float(args.threshold),
        lambda_omega=float(args.lambda_omega),
        candidates=int(args.candidates),
        traversal_walkers=walkers,
        traversal_hops=int(args.hops),
    )
    bus = AnnounceBus(capacity=int(args.bus_capacity))
    C.bus = bus
    adc = ADC()
    nx_like = SimpleNamespace(
        connectome=C,
        adc=adc,
        run_dir=str(run_dir),
        checkpoint_format="h5",
        N=int(args.neurons),
        k=int(args.k),
        seed=int(args.seed),
        dt=1.0 / max(1e-9, float(args.hz)),
        _emit_step=0,
        _phase={"phase": 0},
        scout_visits=int(args.scout_visits),
        scout_edges=int(args.scout_edges),
        cold_head_k=int(args.cold_head_k),
        cold_half_life_ticks=int(args.cold_half_life_ticks),
        b1_half_life_ticks=50,
        b1_detector=SimpleNamespace(z_spike=1.0, hysteresis=1.0),
    )
    eng = CoreEngine(nx_like)
    world = CurriculumWorld(args.curriculum, args.stream_file, int(args.seed), bool(args.reafference))
    motor = FixedGroupActuator(
        n=int(args.neurons),
        group_size=int(args.motor_group_size),
        salt=f"orthad-motor-v2:{args.seed}",
        threshold=float(args.motor_threshold),
        decay=float(args.motor_decay),
        cooldown=int(args.motor_cooldown),
        run_dir=run_dir,
    )
    return C, bus, adc, nx_like, eng, world, motor


def run_ticks(args: Any, run_dir: Path, start_tick: int, stop_tick: int, C: Any, bus: Any, adc: Any, nx_like: Any, eng: Any, world: CurriculumWorld, motor: FixedGroupActuator, writer: Any, jf: Any) -> Tuple[int, float]:
    from vdm_rt.runtime.events_adapter import observations_to_events, adc_metrics_to_event
    elapsed_accum = 0.0
    with ScanFirewall(C):
        for tick in range(int(start_tick), int(stop_tick)):
            tt0 = time.perf_counter()
            source, atom, cycle_idx, atom_idx = world.next_atom()
            jf.write(json.dumps({"tick": tick, "source": source, "cycle_index": cycle_idx, "atom_index": atom_idx, "atom": atom}, ensure_ascii=False) + "\n")
            stim = atom_to_indices(atom, int(args.neurons), int(args.stim_group_size), int(args.stim_max_units), salt=f"orthad-input-v2:{args.seed}")
            if stim:
                C.stimulate_indices(stim, amp=float(args.stim_amp))
            sie2 = float(getattr(C, "_last_sie2_valence", 0.0) or 0.0)
            sie_gate = max(0.35, min(1.0, sie2 if sie2 > 0.0 else 1.0))
            t_model = tick / max(1e-9, float(args.hz))
            C.step(t_model, domain_modulation=float(args.domain_modulation), sie_drive=float(sie_gate), use_time_dynamics=bool(args.use_time_dynamics))
            obs = bus.drain(int(args.bus_drain))
            adc.update_from(obs)
            adc_m = adc.get_metrics()
            evs = observations_to_events(obs)
            evs.append(adc_metrics_to_event(adc_m, int(tick)))
            nx_like._emit_step = int(tick)
            eng.step(int(max(1, nx_like.dt * 1000.0)), evs)
            obs_nodes: List[int] = []
            for o in obs:
                try:
                    obs_nodes.extend([int(x) for x in (getattr(o, "nodes", []) or [])])
                except Exception:
                    pass
            fired = motor.observe_nodes(tick, obs_nodes, source="walker_observation", weight=1.0)
            for prim in fired:
                world.push_reafference(prim)
            findings = dict(getattr(C, "findings", {}) or {})
            row = {
                "tick": tick,
                "source": source,
                "cycle_index": cycle_idx,
                "atom_index": atom_idx,
                "atom": atom,
                "obs_count": len(obs),
                "event_count": len(evs),
                "adc_territories": int(adc_m.get("adc_territories", 0)),
                "adc_boundaries": int(adc_m.get("adc_boundaries", 0)),
                "adc_cycle_hits": int(adc_m.get("adc_cycle_hits", 0)),
                "vt_visits": int(findings.get("vt_visits", 0)),
                "vt_unique": int(findings.get("vt_unique", 0)),
                "vt_coverage": float(findings.get("vt_coverage", 0.0)),
                "vt_entropy": float(findings.get("vt_entropy", 0.0)),
                "edges_active": int(findings.get("edges_active", 0)),
                "vertices_active": int(findings.get("vertices_active", 0)),
                "cycles_est": int(findings.get("cycles_est", 0)),
                "sie2_valence": float(getattr(C, "_last_sie2_valence", 0.0) or 0.0),
                "sie_gate": float(sie_gate),
                "motor_fired": " ".join(fired),
                "tick_s": float(time.perf_counter() - tt0),
            }
            if int(args.summary_every) > 0 and (tick % int(args.summary_every) == 0):
                writer.writerow(row)
            elapsed_accum += row["tick_s"]
            if args.pace:
                target = 1.0 / max(1e-9, float(args.hz))
                if row["tick_s"] < target:
                    time.sleep(target - row["tick_s"])
    return int(stop_tick), elapsed_accum


def main() -> int:
    ap = argparse.ArgumentParser(description="Run original VDM-RT on a legal Orthad curriculum with segmented H5 reload testing.")
    ap.add_argument("--repo", type=Path, default=Path.cwd())
    ap.add_argument("--run-dir", type=Path, default=Path("runs/orthad_curriculum_resume"))
    ap.add_argument("--neurons", type=int, default=1000)
    ap.add_argument("--walkers", type=int, default=None)
    ap.add_argument("--k", type=int, default=12)
    ap.add_argument("--hops", type=int, default=3)
    ap.add_argument("--candidates", type=int, default=64)
    ap.add_argument("--threshold", type=float, default=0.15)
    ap.add_argument("--lambda-omega", type=float, default=0.1)
    ap.add_argument("--domain-modulation", type=float, default=1.15625)
    ap.add_argument("--hz", type=float, default=10.0)
    ap.add_argument("--pace", action="store_true")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--ticks", type=int, default=50000)
    ap.add_argument("--segment-ticks", type=int, default=1000, help="Stop, save H5, rebuild, reload, and continue at this interval. Use 0 for one segment.")
    ap.add_argument("--curriculum", choices=sorted(BUILTIN_STREAMS.keys()), default="rich")
    ap.add_argument("--stream-file", type=Path, default=None)
    ap.add_argument("--stim-group-size", type=int, default=4)
    ap.add_argument("--stim-max-units", type=int, default=8)
    ap.add_argument("--stim-amp", type=float, default=0.05)
    ap.add_argument("--motor-group-size", type=int, default=8)
    ap.add_argument("--motor-threshold", type=float, default=40.0)
    ap.add_argument("--motor-decay", type=float, default=0.97)
    ap.add_argument("--motor-cooldown", type=int, default=12)
    ap.add_argument("--reafference", action="store_true")
    ap.add_argument("--checkpoint-every", type=int, default=0, help="Extra checkpoints inside a segment; segment checkpoints always occur.")
    ap.add_argument("--summary-every", type=int, default=100)
    ap.add_argument("--bus-capacity", type=int, default=65536)
    ap.add_argument("--bus-drain", type=int, default=4096)
    ap.add_argument("--scout-visits", type=int, default=16)
    ap.add_argument("--scout-edges", type=int, default=8)
    ap.add_argument("--cold-head-k", type=int, default=256)
    ap.add_argument("--cold-half-life-ticks", type=int, default=200)
    ap.add_argument("--use-time-dynamics", action="store_true", default=True)
    ap.add_argument("--no-time-dynamics", action="store_false", dest="use_time_dynamics")
    args = ap.parse_args()

    repo = args.repo.resolve()
    bootstrap_vdm(repo)
    import numpy as np
    np.random.seed(int(args.seed))
    from vdm_rt.core.memory import save_checkpoint, load_engram

    run_dir = args.run_dir.resolve()
    run_dir.mkdir(parents=True, exist_ok=True)
    walkers = int(args.walkers) if args.walkers is not None else int(round(1.2 * int(args.neurons)))
    cfg = vars(args).copy()
    cfg.update({"walkers_resolved": walkers, "walker_ratio": walkers / max(1, int(args.neurons)), "mode": "legal_curriculum_segmented_resume", "no_illegal_inputs": True})
    with open(run_dir / "run_config.json", "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2, default=str)

    fields = ["tick", "source", "cycle_index", "atom_index", "atom", "obs_count", "event_count", "adc_territories", "adc_boundaries", "adc_cycle_hits", "vt_visits", "vt_unique", "vt_coverage", "vt_entropy", "edges_active", "vertices_active", "cycles_est", "sie2_valence", "sie_gate", "motor_fired", "tick_s"]
    checkpoint_paths: List[str] = []
    reload_events: List[Dict[str, Any]] = []
    t0 = time.time()
    tick = 0
    segment_size = int(args.segment_ticks) if int(args.segment_ticks) > 0 else int(args.ticks)

    C, bus, adc, nx_like, eng, world, motor = build_runtime(args, run_dir)
    tick_csv = run_dir / "tick_rows.csv"
    input_jsonl = run_dir / "input_stream.jsonl"
    with open(tick_csv, "w", newline="", encoding="utf-8") as cf, open(input_jsonl, "w", encoding="utf-8") as jf:
        writer = csv.DictWriter(cf, fieldnames=fields)
        writer.writeheader()
        while tick < int(args.ticks):
            stop = min(int(args.ticks), tick + segment_size)
            tick, _elapsed = run_ticks(args, run_dir, tick, stop, C, bus, adc, nx_like, eng, world, motor, writer, jf)
            cf.flush(); jf.flush()
            # Save segment checkpoint and append extended continuation state.
            before_sig = state_signature(C, adc, world, motor)
            p = save_checkpoint(str(run_dir), int(tick), C, fmt="h5", adc=adc)
            append_runner_state_to_h5(str(p), C, adc, world, motor, int(tick), args)
            checkpoint_paths.append(str(p))
            # Verify actual load integrity, not just file-open success.
            Vc, Vbus, Vadc, Vnx, Veng, Vworld, Vmotor = build_runtime(args, run_dir)
            load_engram(str(p), Vc, Vadc)
            v_loaded_tick = load_runner_state_from_h5(str(p), Vc, Vadc, Vworld, Vmotor)
            after_sig = state_signature(Vc, Vadc, Vworld, Vmotor)
            sig_ok = before_sig == after_sig
            diff_keys = sorted([k for k in set(before_sig) | set(after_sig) if before_sig.get(k) != after_sig.get(k)])
            integrity_event = {"from": str(p), "expected_tick": int(tick), "loaded_tick": int(v_loaded_tick), "tick_ok": int(v_loaded_tick) == int(tick), "state_signature_ok": bool(sig_ok), "diff_keys": diff_keys[:50]}
            reload_events.append(integrity_event)
            if not sig_ok or int(v_loaded_tick) != int(tick):
                raise RuntimeError("H5 integrity verification failed: " + json.dumps(integrity_event))
            # Force a real reload if work remains.
            if tick < int(args.ticks):
                C2, bus2, adc2, nx2, eng2, world2, motor2 = build_runtime(args, run_dir)
                load_engram(str(p), C2, adc2)
                loaded_tick = load_runner_state_from_h5(str(p), C2, adc2, world2, motor2)
                C2.bus = bus2
                del C, bus, adc, nx_like, eng, world, motor
                C, bus, adc, nx_like, eng, world, motor = C2, bus2, adc2, nx2, eng2, world2, motor2

    motor_count = 0
    motor_by_prim = Counter()
    mp = run_dir / "motor_events.jsonl"
    if mp.exists():
        for line in mp.read_text(encoding="utf-8", errors="ignore").splitlines():
            try:
                rec = json.loads(line)
                motor_count += 1
                motor_by_prim[str(rec.get("primitive", ""))] += 1
            except Exception:
                pass

    summary = {
        "run_dir": str(run_dir),
        "repo": str(repo),
        "mode": "legal_curriculum_segmented_resume",
        "curriculum": str(world.name),
        "neurons": int(args.neurons),
        "walkers": int(walkers),
        "walker_ratio": float(walkers / max(1, int(args.neurons))),
        "ticks": int(args.ticks),
        "segment_ticks": int(segment_size),
        "segments": int(len(checkpoint_paths)),
        "reload_count": int(len(reload_events)),
        "reload_all_ok": bool(all(e.get("tick_ok") and e.get("state_signature_ok") for e in reload_events)),
        "reload_events": reload_events,
        "elapsed_s": float(time.time() - t0),
        "mean_wall_tick_s": float((time.time() - t0) / max(1, int(args.ticks))),
        "motor_event_count": int(motor_count),
        "motor_by_primitive": dict(motor_by_prim),
        "final_checkpoint": checkpoint_paths[-1] if checkpoint_paths else None,
        "checkpoints": checkpoint_paths,
        "scan_firewall": "passed",
        "h5_extended_state": True,
        "h5_integrity_verified": bool(all(e.get("tick_ok") and e.get("state_signature_ok") for e in reload_events)),
    }
    with open(run_dir / "run_summary.json", "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
