# VDM sensory aperture control comparison

## Purpose

Test whether the sensory aperture matters as a closed-loop model-controlled receptor organ, and whether a model with less control of the input experience becomes noisier or less organized.

This suite compares four modes on the same 300-tick schedule:

- `closed_loop_1k_300`: model controls aperture actuator groups live.
- `passive_highres_1k_300_wall60`: high-resolution UTE, fixed relaxed aperture, no model control.
- `replay_closed_loop_aperture_1k_300_v2`: fresh model receives the exact aperture state sequence from closed-loop, but its own aperture commands do not control the applied aperture.
- `replay_shift50_1k_300`: fresh model receives the same aperture state distribution as closed-loop, shifted by 50 ticks, so the aperture is non-contingent / mistimed.

All completed comparison runs used:

```text
N = 1000
walkers = 1200
walker:neuron ratio = 1.2
ticks = 300
phases = 100 stable, 100 noisy/missing-closure, 100 return-stable
```

## Main results

### Witness totals

| run | witness_total | stable | noisy_missing_closure | return_stable |
|---|---:|---:|---:|---:|
| closed_loop | 14 | 3 | 9 | 2 |
| passive_highres | 13 | 3 | 7 | 3 |
| replay_exact | 14 | 3 | 9 | 2 |
| replay_shift50 | 9 | 0 | 6 | 3 |

### Aperture schedule

Closed-loop and exact replay used the same applied aperture sequence:

```text
char      113 ticks
punct      83 ticks
position   62 ticks
pair       26 ticks
span       13 ticks
whole       2 ticks
relaxed     1 tick
```

Occlusion ticks in closed-loop / exact replay:

```text
open level 0: 223 ticks
damped level 1: 39 ticks
stronger level 2: 19 ticks
closed level 3: 19 ticks
```

Passive high-res stayed relaxed for all 300 ticks and never occluded.

The shifted replay used the same aperture distribution as closed-loop, but mistimed by 50 ticks.

## Exact replay finding

Exact replay from the closed-loop aperture sequence produced the same trace and witness behavior as closed-loop.

This is expected for this deterministic setup: same seed, same input schedule, same applied aperture state each tick means the fresh model receives the same afferent trajectory and therefore follows the same path. This control confirms that the aperture state is strong enough to reproduce the closed-loop trajectory when replayed exactly.

## Mistimed replay finding

The shifted replay is more informative for the user's question.

It had the same aperture distribution as closed-loop, but the aperture was no longer aligned to the model's own current state and input phase.

Compared to closed-loop:

```text
closed_loop witnesses:   14
shifted_replay witnesses: 9
```

Stable-phase witnesses dropped from 3 to 0. Noisy/missing-closure witnesses dropped from 9 to 6. Return-stable witnesses rose from 2 to 3.

Mean gate pressure:

| phase | closed_loop | shifted_replay |
|---|---:|---:|
| stable | 0.4820 | 0.3980 |
| noisy_missing_closure | 0.7456 | 0.6579 |
| return_stable | 0.4153 | 0.4403 |

Mean release score:

| phase | closed_loop | shifted_replay |
|---|---:|---:|
| stable | 0.2960 | 0.2430 |
| noisy_missing_closure | 0.6126 | 0.5179 |
| return_stable | 0.2543 | 0.2923 |

This does not look like simple panic/babble from losing control. It looks like misalignment: the model was quieter in the original stable/noisy phases, but release shifted into the return-stable period.

## Passive high-res comparison

Passive high-res did not become wildly noisy in this 300-tick window. It produced 13 witnesses versus 14 in closed-loop.

The difference was in phase distribution:

```text
closed_loop:      stable 3, noisy 9, return 2
passive_highres:  stable 3, noisy 7, return 3
```

Passive high-res had no aperture regulation, no occlusion, and no fine-layer boost. It stayed in relaxed mode.

## Trace index comparison

The shifted replay showed stronger restraint and lower interaction in the noisy phase than closed-loop.

Noisy/missing-closure phase:

| run | interaction_index | restraint_index | revision_index |
|---|---:|---:|---:|
| closed_loop | 33.1534 | 12.0039 | 27.2487 |
| passive_highres | 33.5269 | 36.9775 | 14.9580 |
| replay_shift50 | 23.6416 | 41.2136 | 9.5542 |

Return-stable phase:

| run | interaction_index | restraint_index | revision_index |
|---|---:|---:|---:|
| closed_loop | 39.1528 | 33.0655 | 3.6147 |
| passive_highres | 40.9930 | 54.2526 | 0.0000 |
| replay_shift50 | 38.1952 | 49.7141 | 0.0000 |

Interpretation: closed-loop aperture produced more active revision/compare behavior during the noisy/missing-closure phase. Passive and shifted replay were more restrained and less revision-active. That suggests the live aperture surface is not just a noise source; it supports a more engaged adjustment posture.

## Immediate read

The exact replay control shows aperture state strongly determines the trajectory when seed/input/state are identical.

The shifted replay control shows that the same aperture distribution, when mistimed, changes the phase structure of release and reduces noisy-phase revision/interaction.

The passive high-res control was not panicky in this short window, but it also lacked the char/punct/occlusion posture and showed less noisy-phase revision pressure.

The most interesting next run is a longer 900-1800 tick version of:

```text
closed_loop aperture
exact replay
shifted replay
passive high-res
```

with 300-tick H5 bursts and a longer return-stable recovery window. The key metric should be whether closed-loop aperture sustains higher correction/compare during disturbance and better recovery after disturbance than passive or mistimed replay.
