# Sensory occlusion reafferent translation

Ran the 2048 first-person posture index on sensory occlusion traces using tick-by-tick accumulated intent words.

Inputs per tick include selector trace pressure, active ops, gate/release, aperture level, aperture commands, occlusion, and top trace lane metrics.

Outputs:
- witness_accum_word_translation.csv: one translated utterance per witness interval.
- witness_accum_word_topk.csv: top-k candidates per witness.
- phase_composite_translation.csv: one translated composite phrase per phase.
- phase_composite_topk.csv: top-k candidates per phase.
- summary_witness_family_by_phase.csv: witness family counts by run/phase.

Runs processed: smoke_1k_300, smoke_1k_300_apmin2_priority, smoke_1k_300_apmin4
Witness translations: 41
Phase composites: 9
