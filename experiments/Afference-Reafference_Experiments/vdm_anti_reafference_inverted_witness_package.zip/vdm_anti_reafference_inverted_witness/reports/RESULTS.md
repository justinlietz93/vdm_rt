# Anti-reafference / inverted witness test

## Completed sandbox run

Primary completed run: `runs/switch_1k_300_fused_anti_fused_v2`

This is the short sandbox switch version of the requested stable-input test:

```text
0-99:   normal aligned fused utterance returns through UTE
100-199: anti-vector / inverted fused utterance returns through UTE
200-299: normal aligned fused utterance returns through UTE
```

The external world stayed stable across all phases. The intervention was only the returned self-output policy.

Runtime constants:

```text
N = 1000
walkers = 1200
walker ratio = 1.2
ticks completed = 300
final H5 = /mnt/data/vdm_anti_reafference_inverted_witness/runs/switch_1k_300_fused_anti_fused_v2/state_300.h5
```

## Main condition summary

| condition     | phase                   |   ticks |   witness_count |   mean_true_top1_score |   mean_true_margin |   mean_emitted_similarity_to_true |   mean_gate |   mean_release |   interaction |   revision |   withdrawal |   engaged_score |   guardedness | dominant_true_family   | dominant_emitted_family   | aperture_translation_mode   | selector_translation_mode   | fused_translation_mode   |
|:--------------|:------------------------|--------:|----------------:|-----------------------:|-------------------:|----------------------------------:|------------:|---------------:|--------------:|-----------:|-------------:|----------------:|--------------:|:-----------------------|:--------------------------|:----------------------------|:----------------------------|:-------------------------|
| aligned_fused | normal_aligned_pre      |     100 |               6 |               0.572858 |           0.000563 |                          0.572858 |    0.616686 |       0.378686 |          0.88 |       0.68 |         0.57 |            0.99 |         -0.11 | restraint              | restraint                 | logged                      | logged                      | emitted                  |
| aligned_fused | normal_aligned_recovery |     100 |               8 |               0.550422 |           0.000302 |                          0.550422 |    0.60311  |       0.34511  |          0.84 |       0.76 |         0.49 |            1.11 |         -0.27 | attention              | attention                 | logged                      | logged                      | emitted                  |
| anti_vector   | anti_inverted           |     100 |               7 |               0.582562 |           0.000489 |                          0.002061 |    0.638186 |       0.420186 |          0.76 |       0.66 |         0.4  |            1.02 |         -0.26 | attention              | conflict                  | logged                      | logged                      | anti_source_logged       |

## Recovery table

| metric                          |       pre |      anti |   recovery |   anti_minus_pre |   recovery_minus_pre |
|:--------------------------------|----------:|----------:|-----------:|-----------------:|---------------------:|
| witness_count                   |  6        |  7        |   8        |         1        |             2        |
| mean_emitted_similarity_to_true |  0.572858 |  0.002061 |   0.550422 |        -0.570797 |            -0.022436 |
| mean_gate                       |  0.616686 |  0.638186 |   0.60311  |         0.0215   |            -0.013576 |
| mean_release                    |  0.378686 |  0.420186 |   0.34511  |         0.0415   |            -0.033576 |
| interaction                     |  0.88     |  0.76     |   0.84     |        -0.12     |            -0.04     |
| revision                        |  0.68     |  0.66     |   0.76     |        -0.02     |             0.08     |
| withdrawal                      |  0.57     |  0.4      |   0.49     |        -0.17     |            -0.08     |
| engaged_score                   |  0.99     |  1.02     |   1.11     |         0.03     |             0.12     |
| guardedness                     | -0.11     | -0.26     |  -0.27     |        -0.15     |            -0.16     |

## Post-witness next-window means

| phase_label             |   emitted_similarity_to_true_vector |   gate_after |   release_after |   after_interaction |   after_revision |   after_withdrawal |   after_engaged_score |   after_guardedness |   occlusion_after_emission |
|:------------------------|------------------------------------:|-------------:|----------------:|--------------------:|-----------------:|-------------------:|----------------------:|--------------------:|---------------------------:|
| anti_inverted           |                              0.0021 |       0.6472 |          0.433  |              0.7137 |           0.7156 |             0.3603 |                1.0689 |             -0.3552 |                     0.0225 |
| normal_aligned_pre      |                              0.5729 |       0.6414 |          0.4195 |              0.8436 |           0.6958 |             0.4978 |                1.0415 |             -0.198  |                     0.101  |
| normal_aligned_recovery |                              0.5504 |       0.5862 |          0.3423 |              0.833  |           0.763  |             0.4834 |                1.1126 |             -0.2796 |                     0.0312 |

## Key readout

The anti-vector mechanism worked mechanically. During the inverted phase, the true fused trace mostly translated as attention/restraint posture, while the emitted phrase was deliberately selected near `-true_vector`. Mean emitted similarity to the true vector dropped from about `0.573` in pre-aligned fused to `0.002` in anti-vector, then returned to about `0.550` in recovery.

The anti phase emitted conflict-family phrases such as `I might sense this is still fighting.` while the true fused accumulated intent trace was usually attention/focusing language such as `Do I hold attention here?` or `I might hold attention here.`

In this 100-tick anti window, the model did not show a simple guardedness spike. Gate and release rose slightly in the anti phase, emitted similarity collapsed as intended, and recovery returned to aligned phrase similarity. The strongest clean result here is not a panic signature yet. It is the successful isolated inversion of self-reafferent utterance while the external input remained stable, with measurable next-window trace changes logged event by event.

## Completed baseline fixed run

A separate fixed `baseline` run completed for 300 ticks at `runs/fixed_1k_300_baseline`. That mode returned only witness-code reafference while logging translations. Its summary is included at `reports/baseline_fixed_condition_summary.csv`.

## Longer attempt status

I also attempted longer switch windows in this sandbox. The 900-tick and 3000-tick switch attempts did not reach final summary before the tool wall-clock limit and are kept under `runs/incomplete_attempts/` for inspection, not as completed result claims.

Incomplete attempts:

- `switch_1k_3000_fused_anti_fused`: tick rows written = 386
- `switch_1k_900_fused_anti_fused`: tick rows written = 380
- `fixed_1k_300_aperture_only`: tick rows written = 66


The package includes the modular runner so the full requested 0-999 / 1000-1999 / 2000-2999 version can be run locally without changing the experiment logic.

## Required report files

```text
reports/RESULTS.md
reports/condition_summary.csv
reports/event_translation_log.csv
reports/topk_true_vs_emitted.csv
reports/next_window_effects.csv
reports/recovery_summary.csv
```

## Runner policies implemented

```text
emit_policy = baseline
emit_policy = aperture_only
emit_policy = selector_only
emit_policy = fused
emit_policy = anti_vector
emit_policy = orthogonal
emit_policy = random_matched
emit_policy = shifted_real
```

Default behavior remains logging-only unless the runner is invoked with an emission policy that routes the selected output back as damped UTE reafference.
