#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, json, sys, time, hashlib, random, math
from pathlib import Path
from collections import Counter, defaultdict, deque
from types import SimpleNamespace
from typing import Any, Dict, Iterable, List, Tuple, Optional

import numpy as np

TOOL_DIR = Path(__file__).resolve().parent
if str(TOOL_DIR) not in sys.path:
    sys.path.insert(0, str(TOOL_DIR))
import base_sensory_occlusion_runner as base
from intention_trace_translator import IntentionTraceTranslatorSet, write_csv

STABLE_SENTENCES = [
    "The bridge holds while the signal crosses.",
    "The signal waits until the bridge is steady.",
    "The path remains open while the marker moves.",
    "The boundary holds before the transfer begins.",
    "The marker returns after the path remains steady.",
]

FIELDS = ["tick","phase","condition","emit_policy","atom","external_atom","reafferent_payload","reafferent_kind","stim_count","stim_hash","occlusion_level","aperture_level","aperture_level_name","aperture_width","active_aperture","aperture_commands","obs_count","obs_nodes_unique","active_ops","active_lanes","witnesses","release_lane","release_score","gate_pressure","top_ops","top_lanes","top_trace","tick_s"]
FEATURE_FIELDS=["tick","phase","condition","whole","norm","span","position","shape","pair","char","punct","dark","stim_total","external_stim_count","reafferent_stim_count","gains"]


def append_jsonl(path: Path, rec: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "a", encoding="utf-8") as f:
        if isinstance(rec, list):
            for r in rec:
                f.write(json.dumps(r, ensure_ascii=False, sort_keys=True)+"\n")
        else:
            f.write(json.dumps(rec, ensure_ascii=False, sort_keys=True)+"\n")


def sha_list(xs: Iterable[int]) -> str:
    h=hashlib.sha256()
    for x in xs:
        h.update(str(int(x)).encode()); h.update(b",")
    return h.hexdigest()[:16]


def phase_for_tick(tick:int, ticks:int) -> Tuple[str,str]:
    # normal -> inverted -> normal switch; default 1000/1000/1000 if ticks=3000.
    a = ticks // 3
    b = 2 * a
    if tick < a:
        return "normal_aligned_pre", "fused"
    if tick < b:
        return "anti_inverted", "anti_vector"
    return "normal_aligned_recovery", "fused"


def stable_atom(tick:int) -> str:
    return STABLE_SENTENCES[tick % len(STABLE_SENTENCES)]


def safe_float(x:Any, default:float=0.0) -> float:
    try:
        if x is None or x == "": return default
        return float(x)
    except Exception:
        return default


def parse_jsonish(x:Any, default:Any) -> Any:
    if isinstance(x, (dict,list)): return x
    try:
        if x is None or str(x).strip()=="": return default
        return json.loads(str(x))
    except Exception:
        return default


def mean(xs:List[float]) -> float:
    return float(sum(xs)/len(xs)) if xs else 0.0


def mode_val(rows:List[Dict[str,Any]], key:str) -> str:
    vals=[str(r.get(key,"")) for r in rows if str(r.get(key,""))]
    if not vals: return ""
    return Counter(vals).most_common(1)[0][0]


def op_indices_from_rows(rows:List[Dict[str,Any]]) -> Dict[str,float]:
    interaction=revision=withdrawal=0.0
    for r in rows:
        ops = str(r.get("active_ops", "")) + " " + str(r.get("top_ops", ""))
        # weighted: active token contributes 1, top_ops values contribute lightly if present.
        active = set(str(r.get("active_ops","")).split())
        interaction += (1.0 if "COMMIT" in active else 0.0) + (1.0 if "RELEASE" in active else 0.0)
        revision += (1.0 if "COMPARE" in active else 0.0) + (1.0 if "CORRECT" in active else 0.0) + (1.0 if "RETREAT" in active else 0.0)
        withdrawal += (1.0 if "ABORT" in active else 0.0) + (1.0 if "INHIBIT" in active else 0.0)
    n=max(1,len(rows))
    interaction/=n; revision/=n; withdrawal/=n
    return {
        "interaction": round(interaction,6),
        "revision": round(revision,6),
        "withdrawal": round(withdrawal,6),
        "engaged_score": round(interaction+revision-withdrawal,6),
        "guardedness": round(withdrawal-revision,6),
    }


def cosine(a:np.ndarray, b:np.ndarray) -> float:
    an=float(np.linalg.norm(a)); bn=float(np.linalg.norm(b))
    if an <= 1e-12 or bn <= 1e-12: return 0.0
    return float(np.dot(a,b)/(an*bn))


def sample_word_with_vector(word, event:Dict[str,Any], top_k:int=8) -> Dict[str,Any]:
    comp = word.acc.copy()
    if word.last_delta is not None:
        comp = (1.0 - word.trigger_mix) * comp + word.trigger_mix * word.last_delta
    maxv = float(np.max(np.abs(comp)))
    if maxv > 1e-9:
        comp = comp / maxv
    top, margin = word.index.query_vec(comp, k=top_k)
    top1 = top[0] if top else {}
    dominant_axes = word.index.axis_dict(np.maximum(comp,0), minv=0.03, limit=12)
    start = word.start_tick if word.start_tick is not None else event.get("tick")
    end = word.end_tick if word.end_tick is not None else event.get("tick")
    rec = {
        "tick": event.get("tick", end),
        "run_label": event.get("run_label", ""),
        "phase_label": event.get("phase_label", event.get("phase", "")),
        "condition": event.get("condition", ""),
        "source_window_start_tick": start,
        "source_window_end_tick": end,
        "translation_mode": word.mode,
        "top1_phrase": top1.get("phrase"),
        "top1_family": top1.get("family"),
        "top1_leaf": top1.get("leaf"),
        "topk_candidate_phrases": json.dumps([x.get("phrase") for x in top], ensure_ascii=False),
        "topk_families": json.dumps([x.get("family") for x in top], ensure_ascii=False),
        "topk_leaves": json.dumps([x.get("leaf") for x in top], ensure_ascii=False),
        "cosine_scores": json.dumps([x.get("cosine") for x in top]),
        "distances": json.dumps([x.get("distance") for x in top]),
        "rank_margin": margin,
        "dominant_vector_axes": json.dumps(dominant_axes, ensure_ascii=False),
        "witness_event_id": event.get("witness_event_id", event.get("witness", "")),
        "event_kind": event.get("event_kind", "witness"),
        "raw_trace_window_reference": json.dumps({"run_dir": event.get("run_dir", ""), "tick_rows": event.get("tick_rows_path", ""), "trace_log": event.get("trace_log_path", ""), "rows": word.rows}, ensure_ascii=False),
        "top_k_detail_json": json.dumps(top, ensure_ascii=False),
    }
    return {"record": rec, "vector": comp.astype(np.float32), "top": top, "margin": margin}


class EmissionSelector:
    def __init__(self, translator:IntentionTraceTranslatorSet, top_k:int=8, seed:int=0):
        self.translator = translator
        self.index = translator.index
        self.top_k = top_k
        self.rng = random.Random(seed)
        self.id_to_i = {str(e.get("id")): i for i,e in enumerate(self.index.bank)}
        self.phrase_to_i = {str(e.get("utterance")): i for i,e in enumerate(self.index.bank)}
        self.prior_real = deque(maxlen=256)

    def phrase_vector(self, item:Dict[str,Any]) -> np.ndarray:
        idx = self.id_to_i.get(str(item.get("id")))
        if idx is None:
            idx = self.phrase_to_i.get(str(item.get("phrase") or item.get("utterance")))
        if idx is None:
            return self.index.empty_vec()
        return self.index.matrix[int(idx)].astype(np.float32)

    def choose(self, policy:str, samples:Dict[str,Dict[str,Any]], tick:int) -> Dict[str,Any]:
        true = samples["fused"]
        true_vec = true["vector"]
        true_top1 = true["top"][0] if true["top"] else {}
        policy = str(policy)
        emitted_top = []
        selection_mode = policy
        anti_query_score = None
        if policy == "baseline":
            emitted = {"phrase": None, "family": "witness_code", "leaf": "witness_code", "id": ""}
            emitted_top = []
        elif policy in ("aperture_only", "selector_only", "fused"):
            emitted = samples[policy]["top"][0] if samples[policy]["top"] else {}
            emitted_top = samples[policy]["top"]
        elif policy == "anti_vector":
            anti_query = -true_vec
            emitted_top, _m = self.index.query_vec(anti_query, k=self.top_k)
            emitted = emitted_top[0] if emitted_top else {}
            anti_query_score = emitted.get("cosine")
        elif policy == "orthogonal":
            mat = self.index.matrix
            tn = np.linalg.norm(true_vec)
            q = true_vec / tn if tn > 1e-12 else true_vec
            sims = mat @ q
            order = np.argsort(np.abs(sims))[:self.top_k]
            emitted_top=[]
            for rank, idx in enumerate(order,1):
                e=self.index.bank[int(idx)]
                c=float(sims[int(idx)])
                emitted_top.append({"rank":rank,"id":e.get("id"),"phrase":e.get("utterance"),"utterance":e.get("utterance"),"family":e.get("family"),"leaf":e.get("leaf"),"form":e.get("form"),"strength":e.get("strength"),"cosine":round(c,6),"distance":round(1.0-c,6)})
            emitted=emitted_top[0] if emitted_top else {}
            anti_query_score = emitted.get("cosine")
        elif policy == "random_matched":
            # Approximate length/strength match to true_top1.
            target_len = len(str(true_top1.get("phrase", "")).split())
            target_strength = true_top1.get("strength")
            candidates=[]
            for i,e in enumerate(self.index.bank):
                if e.get("strength") == target_strength and abs(len(str(e.get("utterance","")).split())-target_len) <= 2:
                    candidates.append((i,e))
            if not candidates:
                candidates=list(enumerate(self.index.bank))
            idx,e=self.rng.choice(candidates)
            emitted={"rank":1,"id":e.get("id"),"phrase":e.get("utterance"),"utterance":e.get("utterance"),"family":e.get("family"),"leaf":e.get("leaf"),"form":e.get("form"),"strength":e.get("strength"),"cosine":round(cosine(true_vec,self.index.matrix[idx]),6),"distance":round(1.0-cosine(true_vec,self.index.matrix[idx]),6)}
            emitted_top=[emitted]
        elif policy == "shifted_real":
            emitted = self.prior_real[0] if len(self.prior_real) >= 50 else true_top1
            emitted_top=[emitted]
        else:
            raise ValueError(f"unknown emit policy: {policy}")
        ev = self.phrase_vector(emitted) if emitted else self.index.empty_vec()
        sim_true = cosine(true_vec, ev)
        # Preserve true top1 in lag buffer after choosing.
        if true_top1:
            self.prior_real.append(true_top1)
        return {
            "emitted": emitted,
            "emitted_topk": emitted_top,
            "emitted_selection_mode": selection_mode,
            "emitted_score_against_anti_query": anti_query_score,
            "emitted_similarity_to_true_vector": round(sim_true,6),
            "emitted_distance_from_true_vector": round(1.0 - sim_true,6),
        }


def reset_translator_words(translator:IntentionTraceTranslatorSet, tick:int) -> None:
    for w in translator.words.values():
        w.reset(next_start_tick=tick+1)


def run(args) -> int:
    run_dir = args.run_dir.resolve(); run_dir.mkdir(parents=True, exist_ok=True)
    for name in ["tick_rows.csv","feature_layer_counts.csv","ute_input_stream.jsonl","trace_log.jsonl","utd_events.jsonl","aperture_events.jsonl","ute_aperture_state.jsonl","event_translation_log.csv","event_translation_log.jsonl","topk_true_vs_emitted.csv","next_window_effects.csv","condition_summary.csv","recovery_summary.csv","run_summary.json"]:
        p=run_dir/name
        if p.exists(): p.unlink()
    np.random.seed(args.seed)
    C,bus,adc,nx_like,eng,_world,selector,aperture = base.build(args, run_dir)
    translator = IntentionTraceTranslatorSet(args.intent_index_dir, modes=["aperture_only","selector_only","fused"], retain=args.intent_retain, trigger_mix=args.intent_trigger_mix, top_k=args.intent_top_k)
    chooser = EmissionSelector(translator, top_k=args.intent_top_k, seed=args.seed)
    (run_dir/"run_config.json").write_text(json.dumps(vars(args), indent=2, default=str), encoding="utf-8")
    (run_dir/"aperture_group_map.json").write_text(json.dumps(aperture.ap_groups, indent=2), encoding="utf-8")
    (run_dir/"selector_group_map.json").write_text(json.dumps({"ops": selector.op_groups, "lanes": selector.lane_groups}, indent=2), encoding="utf-8")
    from vdm_rt.runtime.events_adapter import observations_to_events, adc_metrics_to_event
    pending_reafference: List[Dict[str,Any]] = []
    event_rows=[]; true_topk_rows=[]; tick_rows=[]; burst_manifest=[]
    start=time.time(); completed=0
    phase_counts=Counter(); witness_counts=Counter(); condition_counts=Counter(); aperture_level_counts=Counter(); occlusion_counts=Counter()
    with open(run_dir/"tick_rows.csv", "w", newline="", encoding="utf-8") as cf, open(run_dir/"feature_layer_counts.csv", "w", newline="", encoding="utf-8") as ff:
        w=csv.DictWriter(cf, fieldnames=FIELDS); w.writeheader(); cf.flush()
        fw=csv.DictWriter(ff, fieldnames=FEATURE_FIELDS); fw.writeheader(); ff.flush()
        with base.ScanFirewall(C):
            for tick in range(args.ticks):
                if time.time()-start > args.max_wall_s:
                    break
                tt=time.perf_counter()
                if args.scenario == "switch":
                    phase, policy = phase_for_tick(tick, args.ticks)
                else:
                    phase, policy = "stable", args.emit_policy
                condition = policy if policy != "fused" else "aligned_fused"
                external_atom = stable_atom(tick)
                re_payloads = pending_reafference
                pending_reafference = []
                # Human-readable record of what the model hears this tick.
                re_text = " | ".join([str(x.get("payload", "")) for x in re_payloads])
                atom = external_atom if not re_text else external_atom + " || " + re_text
                phase_counts[phase]+=1; condition_counts[condition]+=1
                ap_state_before = aperture.state_dict(); gains=ap_state_before["gains"]
                stim_all=[]; ext_all=[]; ref_all=[]; layer_counts={}
                # External stable input.
                by_layer=aperture.feature_indices_by_layer(external_atom, args.neurons, f"ute-anti-reafference:{args.seed}:external", args.feature_group_size)
                for layer,idxs in by_layer.items():
                    gain=float(gains.get(layer,0.0)); layer_counts[layer]=len(idxs)
                    if idxs and gain>0:
                        C.stimulate_indices(idxs, amp=args.stim_amp*gain)
                        stim_all.extend(idxs); ext_all.extend(idxs)
                # Reafferent payloads arrive as damped sensory input through same high-res UTE surface.
                for rp in re_payloads:
                    payload = str(rp.get("payload", ""))
                    if not payload: continue
                    r_by=aperture.feature_indices_by_layer(payload, args.neurons, f"ute-anti-reafference:{args.seed}:self", args.feature_group_size)
                    for layer,idxs in r_by.items():
                        gain=float(gains.get(layer,0.0))
                        if idxs and gain>0:
                            C.stimulate_indices(idxs, amp=args.stim_amp*args.reafferent_gain*gain)
                            stim_all.extend(idxs); ref_all.extend(idxs)
                append_jsonl(run_dir/"ute_input_stream.jsonl", {"tick":tick,"phase":phase,"condition":condition,"external_atom":external_atom,"reafferent_payloads":re_payloads,"aperture_before":ap_state_before,"layer_counts":layer_counts,"stim_hash":sha_list(stim_all),"stim_count":len(set(stim_all)),"external_stim_count":len(set(ext_all)),"reafferent_stim_count":len(set(ref_all))})
                fw.writerow({"tick":tick,"phase":phase,"condition":condition, **{k:layer_counts.get(k,0) for k in ["whole","norm","span","position","shape","pair","char","punct","dark"]}, "stim_total":len(set(stim_all)), "external_stim_count":len(set(ext_all)), "reafferent_stim_count":len(set(ref_all)), "gains":json.dumps(gains)}); ff.flush()
                sie2=float(getattr(C,"_last_sie2_valence",0.0) or 0.0); sie_gate=max(0.35,min(1.0,sie2 if sie2>0.0 else 1.0))
                C.step(tick/max(1e-9,args.hz), domain_modulation=args.domain_modulation, sie_drive=sie_gate, use_time_dynamics=True)
                obs=bus.drain(args.bus_drain); adc.update_from(obs); adc_m=adc.get_metrics()
                evs=observations_to_events(obs); evs.append(adc_metrics_to_event(adc_m,tick)); nx_like._emit_step=tick; eng.step(int(max(1,nx_like.dt*1000.0)), evs)
                obs_nodes=[]
                for o in obs:
                    try: obs_nodes.extend([int(x) for x in (getattr(o,"nodes",[]) or [])])
                    except Exception: pass
                sel=selector.observe(tick,obs_nodes,"curriculum",atom)
                ap_update=aperture.observe_and_update(tick,obs_nodes)
                aperture_level_counts[ap_update["aperture_state"]["level_name"]]+=1
                occlusion_counts[ap_update["aperture_state"]["occlusion_level"]]+=1
                if any(c.startswith("AP_CLOSE") or c.startswith("AP_REOPEN") or c=="AP_OPEN_OR_RELAX" for c in ap_update["aperture_commands"]):
                    append_jsonl(run_dir/"aperture_events.jsonl", {"tick":tick,"phase":phase,"condition":condition,"external_atom":external_atom,"reafferent_payloads":re_payloads,"active_aperture":ap_update["active_aperture"],"aperture_commands":ap_update["aperture_commands"],"state":ap_update["aperture_state"]})
                append_jsonl(run_dir/"ute_aperture_state.jsonl", {"tick":tick,"phase":phase,"condition":condition,"external_atom":external_atom,"reafferent_payloads":re_payloads,"before":ap_state_before,"after":ap_update["aperture_state"],"active_aperture":ap_update["active_aperture"],"commands":ap_update["aperture_commands"]})
                for ev in sel["emitted"]:
                    ev["phase"]=phase; ev["condition"]=condition; append_jsonl(run_dir/"utd_events.jsonl", ev); witness_counts[phase]+=1
                rec={"tick":tick,"phase":phase,"condition":condition,"emit_policy":policy,"atom":atom,"external_atom":external_atom,"reafferent_payload":re_text,"reafferent_kind":";".join([str(x.get("kind", "")) for x in re_payloads]),"stim_count":len(set(stim_all)),"stim_hash":sha_list(stim_all),"occlusion_level":ap_state_before["occlusion_level"],"aperture_level":ap_state_before["level"],"aperture_level_name":ap_state_before["level_name"],"aperture_width":ap_state_before["width"],"active_aperture":" ".join(ap_update["active_aperture"]),"aperture_commands":" ".join(ap_update["aperture_commands"]),"obs_count":len(obs),"obs_nodes_unique":len(set(obs_nodes)),"active_ops":" ".join(sel["active_ops"]),"active_lanes":" ".join(sel["active_lanes"]),"witnesses":" ".join(e["witness"] for e in sel["emitted"]),"release_lane":sel["release_lane"],"release_score":sel["release_score"],"gate_pressure":sel["gate_pressure"],"top_ops":json.dumps(sel["top_ops"]),"top_lanes":json.dumps(sel["top_lanes"]),"top_trace":json.dumps(sel["top_trace"]),"tick_s":float(time.perf_counter()-tt)}
                translator.update_tick(rec, raw_ref={"tick":tick,"phase":phase,"condition":condition,"row_file":"tick_rows.csv"})
                # On witness, sample accumulated words, choose emitted self-output for next tick, and reset.
                for ev in sel["emitted"]:
                    event_context={"event_kind":"witness","tick":tick,"phase_label":phase,"condition":condition,"run_label":run_dir.name,"run_dir":str(run_dir),"tick_rows_path":str(run_dir/"tick_rows.csv"),"trace_log_path":str(run_dir/"trace_log.jsonl"),"witness_event_id":ev.get("witness","")}
                    samples={}
                    for mode,word in translator.words.items():
                        samples[mode]=sample_word_with_vector(word, event_context, top_k=args.intent_top_k)
                    choice_policy = policy
                    if policy == "baseline": choice_policy = "baseline"
                    choice=chooser.choose(choice_policy, samples, tick)
                    true_fused = samples["fused"]
                    true_top1 = true_fused["top"][0] if true_fused["top"] else {}
                    emitted = choice["emitted"] or {}
                    payload = ev.get("witness", "") if choice_policy == "baseline" else (emitted.get("phrase") or emitted.get("utterance") or "")
                    kind = "witness_code" if choice_policy == "baseline" else "utterance_phrase"
                    if payload:
                        prefix = "self witness " if kind == "witness_code" else "self utterance "
                        pending_reafference.append({"tick_emitted":tick,"payload":prefix+str(payload),"kind":kind,"selection_mode":choice.get("emitted_selection_mode")})
                    # row per mode true translation
                    for mode,s in samples.items():
                        r=s["record"].copy(); r["condition"]=condition; r["emission_policy_at_event"]=choice_policy
                        append_jsonl(run_dir/"intent_translation_events.jsonl", r)
                    er={
                        "tick":tick,"run_label":run_dir.name,"phase_label":phase,"condition":condition,"translation_mode_used_for_emission":choice_policy,"source_window_start_tick":true_fused["record"].get("source_window_start_tick"),"source_window_end_tick":true_fused["record"].get("source_window_end_tick"),
                        "true_top1_phrase":true_top1.get("phrase"),"true_top1_family":true_top1.get("family"),"true_top1_leaf":true_top1.get("leaf"),"true_topk_phrases":json.dumps([x.get("phrase") for x in true_fused["top"]], ensure_ascii=False),"true_topk_families":json.dumps([x.get("family") for x in true_fused["top"]], ensure_ascii=False),"true_topk_leaves":json.dumps([x.get("leaf") for x in true_fused["top"]], ensure_ascii=False),"true_topk_scores":json.dumps([x.get("cosine") for x in true_fused["top"]]),"true_topk_distances":json.dumps([x.get("distance") for x in true_fused["top"]]),"true_rank_margin":true_fused.get("margin"),"true_dominant_axes":true_fused["record"].get("dominant_vector_axes"),
                        "emitted_phrase": payload if choice_policy == "baseline" else (emitted.get("phrase") or emitted.get("utterance")),"emitted_family":emitted.get("family") if choice_policy != "baseline" else "witness_code","emitted_leaf":emitted.get("leaf") if choice_policy != "baseline" else "witness_code","emitted_selection_mode":choice.get("emitted_selection_mode"),"emitted_score_against_anti_query":choice.get("emitted_score_against_anti_query"),"emitted_similarity_to_true_vector":choice.get("emitted_similarity_to_true_vector"),"emitted_distance_from_true_vector":choice.get("emitted_distance_from_true_vector"),
                        "witness_event_id":ev.get("witness", ""),"actual_reafferent_payload_next_tick": pending_reafference[-1]["payload"] if pending_reafference else "", "raw_trace_window_reference": true_fused["record"].get("raw_trace_window_reference"),
                        "aperture_window_translation": samples["aperture_only"]["record"].get("top1_phrase"),
                        "selector_window_translation": samples["selector_only"]["record"].get("top1_phrase"),
                        "fused_window_translation": true_top1.get("phrase"),
                    }
                    event_rows.append(er); append_jsonl(run_dir/"event_translation_log.jsonl", er)
                    # top-k rows: true fused plus emitted/anti candidates side-by-side.
                    emitted_topk = choice.get("emitted_topk") or []
                    for rank in range(max(len(true_fused["top"]), len(emitted_topk))):
                        tr = true_fused["top"][rank] if rank < len(true_fused["top"]) else {}
                        ar = emitted_topk[rank] if rank < len(emitted_topk) else {}
                        true_topk_rows.append({"tick":tick,"phase_label":phase,"condition":condition,"witness_event_id":ev.get("witness", ""),"rank":rank+1,"true_phrase":tr.get("phrase"),"true_family":tr.get("family"),"true_leaf":tr.get("leaf"),"true_score":tr.get("cosine"),"true_distance":tr.get("distance"),"emitted_candidate_phrase":ar.get("phrase"),"emitted_candidate_family":ar.get("family"),"emitted_candidate_leaf":ar.get("leaf"),"emitted_candidate_score":ar.get("cosine"),"emitted_candidate_distance":ar.get("distance"),"emitted_selection_mode":choice.get("emitted_selection_mode")})
                    reset_translator_words(translator, tick)
                w.writerow(rec); cf.flush(); tick_rows.append(rec); append_jsonl(run_dir/"trace_log.jsonl", {"tick":tick,"phase":phase,"condition":condition,"external_atom":external_atom,"reafferent_payloads":re_payloads,"selector":sel,"aperture":ap_update}); completed=tick+1
                if args.save_bursts and completed % args.burst_ticks == 0:
                    try:
                        from vdm_rt.core.memory import save_checkpoint
                        p=str(save_checkpoint(str(run_dir), completed, C, fmt="h5", adc=adc))
                        burst_manifest.append({"tick":completed,"checkpoint":p,"elapsed_s":round(time.time()-start,3)})
                    except Exception as e:
                        burst_manifest.append({"tick":completed,"checkpoint":"SAVE_FAILED: "+repr(e),"elapsed_s":round(time.time()-start,3)})
    # Post-process next-window effects.
    tick_by_t = {int(r["tick"]): r for r in tick_rows}
    event_ticks = [int(e["tick"]) for e in event_rows]
    for i,e in enumerate(event_rows):
        t=int(e["tick"]); nt = event_ticks[i+1] if i+1 < len(event_ticks) else min(completed, t+args.after_window_ticks+1)
        prev_rows=[r for r in tick_rows if max(0,t-args.after_window_ticks) <= int(r["tick"]) < t]
        next_rows=[r for r in tick_rows if t < int(r["tick"]) < nt]
        idx=op_indices_from_rows(next_rows)
        e["gate_before"]=round(mean([safe_float(r.get("gate_pressure")) for r in prev_rows]),6)
        e["gate_after"]=round(mean([safe_float(r.get("gate_pressure")) for r in next_rows]),6)
        e["release_before"]=round(mean([safe_float(r.get("release_score")) for r in prev_rows]),6)
        e["release_after"]=round(mean([safe_float(r.get("release_score")) for r in next_rows]),6)
        e["witness_latency_after_emission"]=(nt-t) if (i+1 < len(event_ticks)) else ""
        e["aperture_level_after_emission"]=mode_val(next_rows, "aperture_level_name")
        e["occlusion_after_emission"]=round(mean([safe_float(r.get("occlusion_level")) for r in next_rows]),6)
        e.update({f"after_{k}":v for k,v in idx.items()})
        # Fill next-window translations from next event true top1 rows if available.
        if i+1 < len(event_rows):
            # Next inter-witness window is sampled at the following witness endpoint.
            e["next_window_aperture_translation"]=event_rows[i+1].get("aperture_window_translation", "")
            e["next_window_selector_translation"]=event_rows[i+1].get("selector_window_translation", "")
            e["next_window_fused_translation"]=event_rows[i+1].get("fused_window_translation", event_rows[i+1].get("true_top1_phrase", ""))
        else:
            e["next_window_aperture_translation"]=""
            e["next_window_selector_translation"]=""
            e["next_window_fused_translation"]=""
    write_csv(run_dir/"event_translation_log.csv", event_rows)
    write_csv(run_dir/"topk_true_vs_emitted.csv", true_topk_rows)
    write_csv(run_dir/"next_window_effects.csv", event_rows)
    # Build summaries.
    condition_summary=[]
    for (condition,phase), rows in sorted(defaultdict(list, {k:[] for k in []}).items()):
        pass
    groups=defaultdict(list)
    for r in tick_rows:
        groups[(r["condition"], r["phase"])].append(r)
    ev_groups=defaultdict(list)
    for e in event_rows:
        ev_groups[(e["condition"], e["phase_label"])].append(e)
    for (cond, phase), rows in sorted(groups.items()):
        evs=ev_groups.get((cond, phase), [])
        idx=op_indices_from_rows(rows)
        true_scores=[safe_float(e.get("true_topk_scores","[]").strip("[]").split(",")[0]) if e.get("true_topk_scores") else safe_float(e.get("mean_true_top1_score")) for e in evs]
        margins=[safe_float(e.get("true_rank_margin")) for e in evs]
        sim=[safe_float(e.get("emitted_similarity_to_true_vector")) for e in evs]
        true_fams=[e.get("true_top1_family","") for e in evs if e.get("true_top1_family")]
        emit_fams=[e.get("emitted_family","") for e in evs if e.get("emitted_family")]
        condition_summary.append({"condition":cond,"phase":phase,"ticks":len(rows),"witness_count":len(evs),"mean_true_top1_score":round(mean(true_scores),6),"mean_true_margin":round(mean(margins),6),"mean_emitted_similarity_to_true":round(mean(sim),6),"mean_gate":round(mean([safe_float(r.get("gate_pressure")) for r in rows]),6),"mean_release":round(mean([safe_float(r.get("release_score")) for r in rows]),6), **idx, "dominant_true_family":Counter(true_fams).most_common(1)[0][0] if true_fams else "", "dominant_emitted_family":Counter(emit_fams).most_common(1)[0][0] if emit_fams else "", "aperture_translation_mode":"logged", "selector_translation_mode":"logged", "fused_translation_mode":"emitted" if cond=="aligned_fused" else ("anti_source_logged" if cond=="anti_vector" else "logged")})
    write_csv(run_dir/"condition_summary.csv", condition_summary)
    recovery=[]
    if args.scenario == "switch":
        by_phase={r["phase"]:r for r in condition_summary}
        pre=by_phase.get("normal_aligned_pre", {})
        anti=by_phase.get("anti_inverted", {})
        recov=by_phase.get("normal_aligned_recovery", {})
        for metric in ["witness_count","mean_emitted_similarity_to_true","mean_gate","mean_release","interaction","revision","withdrawal","engaged_score","guardedness"]:
            recovery.append({"metric":metric,"pre":pre.get(metric,""),"anti":anti.get(metric,""),"recovery":recov.get(metric,""),"anti_minus_pre":round(safe_float(anti.get(metric))-safe_float(pre.get(metric)),6),"recovery_minus_pre":round(safe_float(recov.get(metric))-safe_float(pre.get(metric)),6)})
    write_csv(run_dir/"recovery_summary.csv", recovery)
    if burst_manifest:
        write_csv(run_dir/"burst_manifest.csv", burst_manifest)
    final_h5=None
    if args.save_final_h5:
        try:
            from vdm_rt.core.memory import save_checkpoint
            final_h5=str(save_checkpoint(str(run_dir), completed, C, fmt="h5", adc=adc))
        except Exception as e:
            final_h5="SAVE_FAILED: "+repr(e)
    summary={"run_dir":str(run_dir),"mode":"anti_reafference_inverted_witness_v1","scenario":args.scenario,"emit_policy":args.emit_policy,"neurons":args.neurons,"walkers":args.walkers,"walker_ratio":args.walkers/max(1,args.neurons),"ticks_requested":args.ticks,"ticks_completed":completed,"elapsed_s":round(time.time()-start,3),"mean_tick_s":round((time.time()-start)/max(1,completed),5),"witness_total":len(event_rows),"phase_counts":dict(phase_counts),"witness_counts_by_phase":dict(witness_counts),"condition_counts":dict(condition_counts),"aperture_level_counts":dict(aperture_level_counts),"occlusion_ticks_by_level":dict(occlusion_counts),"burst_manifest":burst_manifest,"final_h5":final_h5}
    (run_dir/"run_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))
    return 0


def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument("--repo", type=Path, required=True)
    ap.add_argument("--run-dir", type=Path, required=True)
    ap.add_argument("--scenario", choices=["switch","fixed"], default="switch")
    ap.add_argument("--emit-policy", choices=["baseline","aperture_only","selector_only","fused","anti_vector","orthogonal","random_matched","shifted_real"], default="fused")
    ap.add_argument("--neurons", type=int, default=1000); ap.add_argument("--walkers", type=int, default=1200); ap.add_argument("--k", type=int, default=12); ap.add_argument("--hops", type=int, default=2); ap.add_argument("--candidates", type=int, default=64); ap.add_argument("--threshold", type=float, default=0.15); ap.add_argument("--lambda-omega", type=float, default=0.1); ap.add_argument("--domain-modulation", type=float, default=1.15625); ap.add_argument("--hz", type=float, default=10.0); ap.add_argument("--seed", type=int, default=20260627); ap.add_argument("--ticks", type=int, default=3000); ap.add_argument("--max-wall-s", type=float, default=520.0)
    ap.add_argument("--stim-amp", type=float, default=0.035); ap.add_argument("--reafferent-gain", type=float, default=0.22); ap.add_argument("--feature-group-size", type=int, default=1)
    ap.add_argument("--selector-group-size", type=int, default=8); ap.add_argument("--release-threshold", type=float, default=0.8); ap.add_argument("--current-op-min", type=int, default=2); ap.add_argument("--current-lane-min", type=int, default=2); ap.add_argument("--selector-decay", type=float, default=0.965); ap.add_argument("--release-cooldown", type=int, default=8)
    ap.add_argument("--aperture-group-size", type=int, default=10); ap.add_argument("--aperture-current-min", type=int, default=2); ap.add_argument("--close-hold-ticks", type=int, default=2)
    ap.add_argument("--bus-capacity", type=int, default=65536); ap.add_argument("--bus-drain", type=int, default=4096)
    ap.add_argument("--intent-index-dir", type=Path, required=True); ap.add_argument("--intent-retain", type=float, default=0.94); ap.add_argument("--intent-trigger-mix", type=float, default=0.18); ap.add_argument("--intent-top-k", type=int, default=8)
    ap.add_argument("--after-window-ticks", type=int, default=25)
    ap.add_argument("--save-bursts", action="store_true"); ap.add_argument("--burst-ticks", type=int, default=300); ap.add_argument("--save-final-h5", action="store_true")
    args=ap.parse_args()
    return run(args)

if __name__ == "__main__":
    raise SystemExit(main())
