# VDM anti-reafference / inverted witness package

This package integrates the 2048 accumulated intention-trace translator into an anti-reafference / inverted witness test.

Main completed run:

```text
runs/switch_1k_300_fused_anti_fused_v2
```

Main report:

```text
reports/RESULTS.md
```

Run full requested local version:

```bash
python tools/run_anti_reafference_experiment.py \
  --repo codebase/vdm_rt-main \
  --run-dir runs/switch_1k_3000_fused_anti_fused_local \
  --intent-index-dir index \
  --ticks 3000 \
  --max-wall-s 3600 \
  --save-bursts \
  --save-final-h5
```

The runner keeps external input stable and changes only the returned self-output policy during the switch test.
