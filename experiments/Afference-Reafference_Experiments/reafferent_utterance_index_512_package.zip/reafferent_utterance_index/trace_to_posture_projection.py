#!/usr/bin/env python3
"""
General trace-window -> posture-axis projection scaffold.

This is the bridge between VDM trace logs and the reafferent utterance index.
It intentionally outputs subject-agnostic cognitive/posture axes, not domain labels.

You should wire real field names from your runtime into `project_trace_window`.
The function accepts rows as dictionaries and tolerates missing keys.
"""
from __future__ import annotations

import math
from typing import Dict, Iterable, List

AXES = [
    'recognition','familiarity','novelty','curiosity','attention','engagement',
    'uncertainty','confusion','hesitation','confidence','confirmation','realization',
    'surprise','mismatch','conflict','rejection','restraint','readiness','search',
    'comparison','connection','separation','ordering','completion','incompletion',
    'repair','attraction','avoidance','intensity','valence',
]

OPS = [
    'SELECT','HOLD','RELEASE','ADVANCE','COMMIT','ABORT','RETREAT','COMPARE',
    'AMPLIFY','INHIBIT','MERGE','SPLIT','DAMP','CORRECT','RETRACT',
]


def clamp01(x: float) -> float:
    return max(0.0, min(1.0, float(x)))


def get_num(row: Dict[str, object], *names: str, default: float = 0.0) -> float:
    for name in names:
        if name in row and row[name] not in (None, ''):
            try:
                return float(row[name])
            except Exception:
                pass
    return default


def op_active(row: Dict[str, object], op: str) -> float:
    # Accept several common layouts: op_SELECT, active_ops list/string, command names.
    val = get_num(row, f'op_{op}', f'active_{op}', default=0.0)
    if val:
        return min(1.0, val)
    active = row.get('active_ops') or row.get('ops') or row.get('commands') or ''
    if isinstance(active, (list, tuple, set)):
        return 1.0 if op in active else 0.0
    return 1.0 if op in str(active).upper().replace(',', ' ').split() else 0.0


def project_trace_window(rows: Iterable[Dict[str, object]], witness_tick: int | None = None, tau: float = 10.0) -> Dict[str, float]:
    rows = list(rows)
    if not rows:
        return {axis: 0.0 for axis in AXES}
    if witness_tick is None:
        witness_tick = int(get_num(rows[-1], 'tick', default=len(rows)-1))

    acc = {axis: 0.0 for axis in AXES}
    wsum = 0.0
    seen_inputs = {}
    prior_near_release = 0.0
    release_lane_switches = 0
    prev_release_lane = None

    for row in rows:
        tick = int(get_num(row, 'tick', default=witness_tick))
        age = max(0, witness_tick - tick)
        w = math.exp(-age / tau)
        wsum += w

        gate = get_num(row, 'gate_pressure', 'gate', default=0.0)
        rel = get_num(row, 'release_score', 'release', default=0.0)
        witness = get_num(row, 'witness', 'did_witness', default=0.0)
        if str(row.get('witness', '')).lower() in ('true', 'yes'):
            witness = 1.0

        select = op_active(row, 'SELECT')
        hold = op_active(row, 'HOLD')
        release = op_active(row, 'RELEASE')
        advance = op_active(row, 'ADVANCE')
        commit = op_active(row, 'COMMIT')
        abort = op_active(row, 'ABORT')
        retreat = op_active(row, 'RETREAT')
        compare = op_active(row, 'COMPARE')
        amplify = op_active(row, 'AMPLIFY')
        inhibit = op_active(row, 'INHIBIT')
        merge = op_active(row, 'MERGE')
        split = op_active(row, 'SPLIT')
        damp = op_active(row, 'DAMP')
        correct = op_active(row, 'CORRECT')
        retract = op_active(row, 'RETRACT')

        input_id = str(row.get('input_id') or row.get('stimulus_id') or row.get('input') or '')
        repeated = 0.0
        if input_id:
            repeated = 1.0 if input_id in seen_inputs else 0.0
            seen_inputs[input_id] = seen_inputs.get(input_id, 0) + 1

        release_lane = row.get('release_lane') or row.get('lane') or row.get('emitted_lane')
        if release_lane and prev_release_lane and release_lane != prev_release_lane:
            release_lane_switches += 1
        if release_lane:
            prev_release_lane = release_lane

        near_release = 1.0 if (rel > 0.5 and gate > 0.5 and not witness) else 0.0
        prior_near_release = max(prior_near_release, near_release * w)

        high_pressure = clamp01(gate / 1.3)
        high_release = clamp01(rel / 1.0)

        # Generic posture projection. These are starting weights, not final scientific claims.
        acc['attention'] += w * clamp01(select + compare + high_pressure * .4)
        acc['engagement'] += w * clamp01(select + release + advance + high_pressure * .3)
        acc['recognition'] += w * clamp01(.45*repeated + .30*select + .30*high_release + .20*witness + .15*commit - .20*abort - .15*retreat)
        acc['familiarity'] += w * clamp01(.65*repeated + .25*select + .15*commit)
        acc['novelty'] += w * clamp01((1.0-repeated) * (.35 + .35*compare + .25*curiosity_like(compare, select)))
        acc['curiosity'] += w * clamp01(.35*select + .45*compare + .25*high_pressure + .20*(1.0-repeated))
        acc['uncertainty'] += w * clamp01(.40*compare + .35*retreat + .35*abort + .25*hold + .20*inhibit - .25*commit - .25*witness)
        acc['confusion'] += w * clamp01(.35*compare + .40*retreat + .35*abort + .25*split + .20*inhibit)
        acc['hesitation'] += w * clamp01(.55*hold + .35*retreat + .35*abort + .25*near_release + .20*retract)
        acc['confidence'] += w * clamp01(.35*commit + .35*witness + .30*high_release + .25*select - .30*uncertain_like(compare, retreat, abort))
        acc['confirmation'] += w * clamp01(.35*witness + .35*commit + .30*select + .25*release + .20*advance + .20*prior_near_release)
        acc['realization'] += w * clamp01(.30*correct + .25*merge + .25*commit + .20*witness + .20*advance)
        acc['surprise'] += w * clamp01(.35*(1.0-repeated) + .25*split + .20*high_pressure)
        acc['mismatch'] += w * clamp01(.45*abort + .35*retreat + .35*compare + .30*inhibit + .20*retract)
        acc['conflict'] += w * clamp01(.35*compare + .30*split + .30*inhibit + .25*hold + .20*amplify)
        acc['rejection'] += w * clamp01(.60*abort + .45*retreat + .25*retract + .20*inhibit)
        acc['restraint'] += w * clamp01(.55*hold + .35*inhibit + .25*damp + .20*(amplify and not release))
        acc['readiness'] += w * clamp01(.45*advance + .40*release + .35*witness + .25*high_release - .30*hold)
        acc['search'] += w * clamp01(.45*compare + .30*select + .25*uncertain_like(compare, retreat, abort) + .25*(1.0-repeated))
        acc['comparison'] += w * clamp01(compare + .20*split + .15*merge)
        acc['connection'] += w * clamp01(.45*merge + .30*commit + .25*correct + .20*select)
        acc['separation'] += w * clamp01(.45*split + .35*abort + .25*compare + .20*retreat)
        acc['ordering'] += w * clamp01(.30*advance + .25*select + .20*correct + .15*commit)
        acc['completion'] += w * clamp01(.45*witness + .35*commit + .30*release + .25*advance + .20*high_release)
        acc['incompletion'] += w * clamp01(.35*hold + .35*compare + .25*near_release + .25*uncertain_like(compare, retreat, abort) - .20*witness)
        acc['repair'] += w * clamp01(.50*correct + .35*damp + .25*retract + .25*abort)
        acc['attraction'] += w * clamp01(.35*select + .35*high_pressure + .25*release + .25*amplify)
        acc['avoidance'] += w * clamp01(.45*retreat + .40*abort + .30*inhibit + .20*damp)
        acc['intensity'] += w * clamp01(.45*high_pressure + .35*high_release + .25*amplify + .20*inhibit)
        acc['valence'] += w * max(-1.0, min(1.0, .35*confirmation + .25*completion + .20*recognition_proxy(repeated, witness) - .30*mismatch_proxy(abort, retreat, compare)))

    if wsum <= 0:
        return acc
    # Normalize by accumulated weights, then clamp to [-1,1].
    out = {k: max(-1.0, min(1.0, v / wsum)) for k, v in acc.items()}
    # Lane switching pushes confusion/conflict gently after normalization.
    if release_lane_switches:
        out['confusion'] = clamp01(out['confusion'] + min(.25, release_lane_switches * .03))
        out['conflict'] = clamp01(out['conflict'] + min(.20, release_lane_switches * .02))
    return out


def uncertain_like(compare: float, retreat: float, abort: float) -> float:
    return clamp01(.45*compare + .35*retreat + .35*abort)


def curiosity_like(compare: float, select: float) -> float:
    return clamp01(.35*compare + .25*select)


def recognition_proxy(repeated: float, witness: float) -> float:
    return clamp01(.45*repeated + .35*witness)


def mismatch_proxy(abort: float, retreat: float, compare: float) -> float:
    return clamp01(.45*abort + .35*retreat + .25*compare)
