#!/usr/bin/env python3
"""
Query the temporary VDM reafferent utterance index.

The index is not a text embedding model. It expects a posture-axis vector
computed from the trace history since the last witness event.

Example:
  python query_reafferent_index.py --axis recognition=.9 --axis confirmation=.75 --axis hesitation=.25 --top-k 8

JSON input example:
  python query_reafferent_index.py --json axis_vector.json --top-k 8
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np


def load_index(index_dir: Path):
    data = np.load(index_dir / 'utterance_index.npz', allow_pickle=True)
    return {
        'vectors': data['vectors'].astype(np.float32),
        'ids': data['ids'].astype(str),
        'utterances': data['utterances'].astype(str),
        'families': data['families'].astype(str),
        'strengths': data['strengths'].astype(np.float32),
        'axes': data['axes'].astype(str).tolist(),
    }


def normalize(v: np.ndarray) -> np.ndarray:
    n = float(np.linalg.norm(v))
    if n == 0.0:
        return v
    return v / n


def axis_dict_to_vector(axis_scores: Dict[str, float], axes: List[str]) -> np.ndarray:
    idx = {a: i for i, a in enumerate(axes)}
    v = np.zeros(len(axes), dtype=np.float32)
    for key, value in axis_scores.items():
        if key not in idx:
            valid = ', '.join(axes)
            raise SystemExit(f'Unknown axis {key!r}. Valid axes: {valid}')
        v[idx[key]] = float(value)
    return normalize(v)


def query(axis_scores: Dict[str, float], index_dir: Path, top_k: int = 8) -> List[Dict[str, object]]:
    index = load_index(index_dir)
    q = axis_dict_to_vector(axis_scores, index['axes'])
    scores = index['vectors'] @ q
    order = np.argsort(-scores)[:top_k]
    results = []
    for rank, i in enumerate(order, start=1):
        results.append({
            'rank': rank,
            'score': float(scores[i]),
            'id': str(index['ids'][i]),
            'utterance': str(index['utterances'][i]),
            'family': str(index['families'][i]),
            'strength': float(index['strengths'][i]),
        })
    return results


def parse_axis(items: List[str]) -> Dict[str, float]:
    out: Dict[str, float] = {}
    for item in items:
        if '=' not in item:
            raise SystemExit(f'Expected axis=value, got: {item}')
        k, v = item.split('=', 1)
        out[k.strip()] = float(v)
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument('--index-dir', default=str(Path(__file__).resolve().parent))
    ap.add_argument('--axis', action='append', default=[], help='axis=value, repeatable')
    ap.add_argument('--json', help='JSON file containing {axis: score}')
    ap.add_argument('--top-k', type=int, default=8)
    args = ap.parse_args()

    axis_scores: Dict[str, float] = {}
    if args.json:
        with open(args.json, 'r', encoding='utf-8') as f:
            axis_scores.update(json.load(f))
    axis_scores.update(parse_axis(args.axis))
    if not axis_scores:
        raise SystemExit('Provide --axis axis=value or --json axis_vector.json')

    results = query(axis_scores, Path(args.index_dir), args.top_k)
    print(json.dumps(results, indent=2))


if __name__ == '__main__':
    main()
