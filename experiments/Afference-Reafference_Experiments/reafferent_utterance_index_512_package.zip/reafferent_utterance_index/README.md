# VDM Temporary Reafferent Utterance Index

This package is a subject-agnostic first-person utterance index for a temporary actuator-witness translation layer.

It is designed for this runtime shape:

```text
trace history since last witness
→ recency-weighted posture/symbolic-intent vector
→ cosine search over first-person utterance bank
→ emit one utterance as damped reafference
```

The model receives only the selected utterance, for example:

```text
I recognize this.
```

It does not receive the witness code, lane labels, trace labels, family IDs, or vectors.

## Files

- `utterance_bank.jsonl` — 512 curated first-person utterance entries with axis scores and normalized vectors.
- `utterance_index.npz` — compressed normalized vector matrix and metadata for fast cosine search.
- `index_schema.json` — axis list and design metadata.
- `query_reafferent_index.py` — simple CLI/query helper.
- `trace_to_posture_projection.py` — subject-agnostic trace-window to posture-axis projection scaffold.

## Axis space

The index uses 30 subject-agnostic axes:

```text
recognition, familiarity, novelty, curiosity, attention, engagement,
uncertainty, confusion, hesitation, confidence, confirmation, realization,
surprise, mismatch, conflict, rejection, restraint, readiness, search,
comparison, connection, separation, ordering, completion, incompletion,
repair, attraction, avoidance, intensity, valence
```

These are not domain labels. They should work across chemistry, music, code, ethics, tools, social language, mathematics, memory, anomaly, and embodiment.

## Query example

```bash
python query_reafferent_index.py   --axis recognition=.90   --axis confirmation=.75   --axis hesitation=.20   --axis confidence=.70   --top-k 8
```

## Integration note

The included projection scaffold is deliberately conservative. It gives a starting mapping from trace-window features into the posture-axis space, but it is not a final scientific claim. Tune it against your witness windows.

Good runtime policy:

```text
emit top-1 utterance
log top-k candidates + vector + witness code separately
keep raw witness code and full trace history unchanged
```
