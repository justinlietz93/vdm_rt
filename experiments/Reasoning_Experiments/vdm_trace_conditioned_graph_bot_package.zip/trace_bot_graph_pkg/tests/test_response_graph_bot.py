from deterministic_vdm_bot import DeterministicConversationBot


def test_response_graph_is_deterministic_for_same_seed():
    records = [
        {"tick": 1, "true_top1_phrase": "I think I hold attention here.", "true_top1_family": "attention", "true_top1_leaf": "focusing"},
        {"tick": 2, "true_top1_phrase": "I think I hold down the pressure.", "true_top1_family": "restraint", "true_top1_leaf": "suppression"},
        {"tick": 3, "true_top1_phrase": "I need more to know.", "true_top1_family": "uncertainty", "true_top1_leaf": "insufficient_signal"},
    ]
    a = DeterministicConversationBot(seed=20260627)
    b = DeterministicConversationBot(seed=20260627)
    out_a = [a.step(r).to_dict() for r in records]
    out_b = [b.step(r).to_dict() for r in records]
    assert out_a == out_b


def test_response_graph_does_not_repeat_single_canned_family_phrase():
    bot = DeterministicConversationBot(seed=20260627)
    records = [
        {"tick": i, "true_top1_phrase": "I think I hold attention here.", "true_top1_family": "attention", "true_top1_leaf": "focusing"}
        for i in range(1, 7)
    ]
    replies = [bot.step(r).reply_text for r in records]
    assert len(set(replies)) >= 2
    assert "Shift detected" not in " ".join(replies)
    assert "Keep the signal narrow and steady" not in " ".join(replies)


def test_followup_can_be_selected_and_is_related():
    bot = DeterministicConversationBot(seed=123)
    packets = [bot.step({"tick": i, "true_top1_phrase": "I think I hold attention here.", "true_top1_family": "attention", "true_top1_leaf": "focusing"}) for i in range(1, 12)]
    followups = [p.follow_up_text for p in packets if p.follow_up_text]
    assert followups
    assert all(text.startswith("BOT FOLLOWUP=") for text in followups)
