# Response-graph bot spec

This package replaces the old family-to-canned-sentence bot.

The bot now works like this:

```text
witness event translation
  -> normalized query record
  -> deterministic hashed vector query
  -> seed-biased response-vector index
  -> response graph node
  -> optional related follow-up node
```

The response graph lives at:

```text
configs/response_graph_v1.json
```

Each response node has:

```text
id
family
leaf
tags
reply_text
action
aperture_hint
stimulus_policy
reafferent_gain_hint
followups
```

The selector does not map one family to one sentence. It builds a query from:

```text
true_top1_phrase
true_top1_family
true_top1_leaf
true_dominant_axes
```

Then it scores every response node by vector similarity, family match, leaf match, seed-biased jitter, and repetition penalties.

The returned text is intentionally structured and low-prose:

```text
BOT ACTION=FOCUS APERTURE=NARROW SIGNAL=STEADY
BOT ACTION=CONTAIN_PRESSURE RELEASE=FALSE
BOT ACTION=COMPARE_PAIR VISIBILITY=BOTH
```

Follow-up behavior:

```text
selected node -> deterministic chance -> related follow-up node
```

When a follow-up fires, the runner sends it immediately as a second reafferent payload on the next tick:

```text
bot reply BOT ACTION=...
bot followup BOT FOLLOWUP=...
```

The chance is deterministic from:

```text
seed
turn count
tick
selected node id
```

So the same run seed and same witness stream produces the same bot stream.

Default comparison runs:

```text
bot_matched_trace
bot_lagged_trace
bot_yoked_replay
```

No no-return baseline is run by default. No true-phrase-return run is run by default. Those were removed from the default package path because the point here is to test the fixed bot coupling, not waste time on baseline passes.
