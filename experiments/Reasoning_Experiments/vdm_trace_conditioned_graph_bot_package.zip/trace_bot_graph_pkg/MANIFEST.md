# Trace-conditioned graph bot package

Files:

- `tools/run_trace_conditioned_bot_suite.py` - user-facing whole-run suite runner.
- `tools/run_trace_conditioned_bot_suite_core.py` - experiment core.
- `tools/analyze_trace_conditioned_bot_results.py` - report generator.
- `tools/base_sensory_occlusion_runner.py` - VDM runtime harness helper.
- `tools/intention_trace_translator.py` - 2048 phrase-index translator.
- `src/deterministic_vdm_bot/` - response-graph bot engine.
- `configs/response_graph_v1.json` - response graph and vector-index nodes.
- `index/` - 2048 phrase bank and vector index.
- `tests/` - deterministic graph-bot tests.
- `setup_env.sh` - creates local venv and installs wrapper dependencies.
- `run_trace_bot_1500.sh` - quick graph-bot run.
- `run_trace_bot_3000.sh` - longer graph-bot run.
- `run_trace_bot_5000.sh` - long graph-bot run.
- `analyze_trace_bot.sh` - reruns report generation on existing results.

The package does not bundle a stale `vdm_rt-main`. Pass your live official repo with `--repo` or as the first shell-script argument.

Default runs:

```text
bot_matched_trace
bot_lagged_trace
bot_yoked_replay
```

Smoke tests performed before packaging:

```text
PYTHONPATH=src pytest -q tests
  6 passed

12-tick suite against a local VDM runtime copy:
  bot_matched_trace complete
  bot_lagged_trace complete
  bot_yoked_replay complete
  reports generated
```
