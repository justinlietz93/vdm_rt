from __future__ import annotations

import hashlib
import json
import math
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence

from .rules import DEFAULT_RULES, Rule, canonical_family, is_uncertain_phrase


PHRASE_FIELDS = (
    "phrase",
    "true_top1_phrase",
    "fused_phrase",
    "selector_phrase",
    "aperture_phrase",
    "translation",
    "top1_phrase",
)

FAMILY_FIELDS = (
    "family",
    "true_top1_family",
    "fused_family",
    "selector_family",
    "aperture_family",
    "top1_family",
)

LEAF_FIELDS = (
    "leaf",
    "true_top1_leaf",
    "fused_leaf",
    "selector_leaf",
    "aperture_leaf",
    "top1_leaf",
)

AXES_FIELDS = (
    "dominant_axes",
    "true_dominant_axes",
    "axes",
)

_DIM = 192
_TOKEN_SEPARATORS = "\t\n\r ,.;:!?()[]{}<>|/\\\"'`=+*"


@dataclass
class BotState:
    turn_count: int = 0
    last_family: str = ""
    family_streak: int = 0
    history: List[str] = field(default_factory=list)
    last_response_id: str = ""
    last_follow_up_id: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class BotPacket:
    tick: Optional[int]
    input_phrase: str
    input_family: str
    input_leaf: str
    reply_text: str
    action: str
    aperture_hint: str
    stimulus_policy: str
    reafferent_gain_hint: float
    state_family: str
    state_streak: int
    is_uncertain: bool
    rule_id: str
    prefix: str = ""
    response_id: str = ""
    response_family: str = ""
    response_leaf: str = ""
    response_score: float = 0.0
    query_seed: int = 0
    query_terms: List[str] = field(default_factory=list)
    top_response_ids: List[str] = field(default_factory=list)
    top_response_scores: List[float] = field(default_factory=list)
    follow_up_text: str = ""
    follow_up_id: str = ""
    follow_up_action: str = ""
    follow_up_probability: float = 0.0
    follow_up_roll: float = 1.0
    selection_mode: str = "response_graph_vector_index"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), sort_keys=True, separators=(",", ":"))


@dataclass(frozen=True)
class ResponseNode:
    id: str
    family: str
    leaf: str
    tags: List[str]
    reply_text: str
    action: str
    aperture_hint: str
    stimulus_policy: str
    reafferent_gain_hint: float
    followups: List[str]
    vector: List[float]


def _default_graph_path() -> Path:
    return Path(__file__).resolve().parents[2] / "configs" / "response_graph_v1.json"


def _first_present(record: Mapping[str, Any], fields: Iterable[str], default: str = "") -> str:
    for field in fields:
        val = record.get(field)
        if val is None:
            continue
        s = str(val).strip()
        if s:
            return s
    return default


def _parse_axes(value: Any) -> List[str]:
    if value is None:
        return []
    if isinstance(value, list):
        return [str(x) for x in value]
    if isinstance(value, tuple):
        return [str(x) for x in value]
    if isinstance(value, str):
        s = value.strip()
        if not s:
            return []
        if s.startswith("["):
            try:
                obj = json.loads(s)
                if isinstance(obj, list):
                    return [str(x) for x in obj]
            except Exception:
                pass
        return [x.strip() for x in s.replace(";", ",").split(",") if x.strip()]
    return [str(value)]


def _first_axes(record: Mapping[str, Any]) -> List[str]:
    for field in AXES_FIELDS:
        if field in record:
            axes = _parse_axes(record.get(field))
            if axes:
                return axes
    return []


def _tick(record: Mapping[str, Any]) -> Optional[int]:
    val = record.get("tick")
    if val is None:
        val = record.get("t")
    try:
        return int(val) if val is not None and str(val).strip() != "" else None
    except Exception:
        return None


def _tokens(text: str) -> List[str]:
    out: List[str] = []
    cur: List[str] = []
    for ch in str(text or "").lower():
        if ch in _TOKEN_SEPARATORS:
            if cur:
                out.append("".join(cur))
                cur.clear()
        else:
            cur.append(ch)
    if cur:
        out.append("".join(cur))
    return [t for t in out if len(t) > 1]


def _hash_float(key: str) -> float:
    h = hashlib.blake2b(key.encode("utf-8"), digest_size=8).digest()
    n = int.from_bytes(h, "little", signed=False)
    return n / float((1 << 64) - 1)


def _signed_hash(key: str) -> float:
    return 1.0 if _hash_float(key) >= 0.5 else -1.0


def _zero() -> List[float]:
    return [0.0] * _DIM


def _add_token(vec: List[float], token: str, weight: float) -> None:
    token = str(token or "").strip().lower()
    if not token:
        return
    for salt in range(3):
        h = hashlib.blake2b(f"{salt}:{token}".encode("utf-8"), digest_size=8).digest()
        n = int.from_bytes(h, "little", signed=False)
        idx = n % _DIM
        vec[idx] += weight * (1.0 if ((n >> 9) & 1) else -1.0)


def _normalize(vec: List[float]) -> List[float]:
    norm = math.sqrt(sum(x * x for x in vec))
    if norm <= 1e-12:
        return vec
    return [x / norm for x in vec]


def _dot(a: Sequence[float], b: Sequence[float]) -> float:
    return float(sum(float(x) * float(y) for x, y in zip(a, b)))


def _vector_from_terms(terms: Iterable[str]) -> List[float]:
    vec = _zero()
    for term in terms:
        _add_token(vec, term, 1.0)
    return _normalize(vec)


def _bias_vector(seed: int) -> List[float]:
    vec = _zero()
    for i in range(48):
        _add_token(vec, f"seed:{seed}:bias:{i}:{int(_hash_float(str(seed)+':'+str(i))*1000000)}", 1.0)
    return _normalize(vec)


def _node_terms(raw: Mapping[str, Any]) -> List[str]:
    terms: List[str] = []
    for field in ("id", "family", "leaf", "action", "aperture_hint", "stimulus_policy", "reply_text"):
        val = str(raw.get(field, ""))
        terms.extend(_tokens(val.replace("_", " ")))
    for tag in raw.get("tags", []) or []:
        terms.extend(_tokens(str(tag).replace("_", " ")))
    fam = str(raw.get("family", "unknown"))
    leaf = str(raw.get("leaf", ""))
    terms.extend([f"family:{fam}"] * 6)
    if leaf:
        terms.extend([f"leaf:{leaf}"] * 3)
    return terms


def _load_graph(path: Optional[Path] = None) -> Dict[str, Any]:
    graph_path = Path(path) if path is not None else _default_graph_path()
    data = json.loads(graph_path.read_text(encoding="utf-8"))
    nodes: Dict[str, ResponseNode] = {}
    for raw in data.get("nodes", []):
        vec = _vector_from_terms(_node_terms(raw))
        node = ResponseNode(
            id=str(raw["id"]),
            family=str(raw.get("family", "unknown")),
            leaf=str(raw.get("leaf", "")),
            tags=[str(x) for x in raw.get("tags", []) or []],
            reply_text=str(raw.get("reply_text", "")),
            action=str(raw.get("action", "")),
            aperture_hint=str(raw.get("aperture_hint", "hold")),
            stimulus_policy=str(raw.get("stimulus_policy", "continue")),
            reafferent_gain_hint=float(raw.get("reafferent_gain_hint", data.get("default_gain", 0.18))),
            followups=[str(x) for x in raw.get("followups", []) or []],
            vector=vec,
        )
        nodes[node.id] = node
    return {
        "config": data,
        "nodes": nodes,
        "path": str(graph_path),
    }


class DeterministicConversationBot:
    """Deterministic response-graph bot. Witness translations query a response-vector index."""

    def __init__(
        self,
        rules: Optional[Mapping[str, Rule]] = None,
        seed: int = 0,
        graph_path: Optional[Path] = None,
        seed_bias_strength: Optional[float] = None,
        followup_probability: Optional[float] = None,
    ) -> None:
        self.rules: Mapping[str, Rule] = rules if rules is not None else DEFAULT_RULES
        self.seed = int(seed)
        graph = _load_graph(graph_path)
        self.graph_config = dict(graph["config"])
        self.nodes: Dict[str, ResponseNode] = dict(graph["nodes"])
        self.state = BotState()
        self.seed_bias_strength = float(seed_bias_strength if seed_bias_strength is not None else self.graph_config.get("seed_bias_strength", 0.12))
        self.followup_probability = float(followup_probability if followup_probability is not None else self.graph_config.get("followup_probability", 0.32))
        self.turn_jitter_strength = float(self.graph_config.get("turn_jitter_strength", 0.025))
        self.repeat_penalty = float(self.graph_config.get("repeat_penalty", 0.18))
        self.same_family_streak_penalty = float(self.graph_config.get("same_family_streak_penalty", 0.035))
        self.max_history = int(self.graph_config.get("max_history", 24))
        self._seed_bias = _bias_vector(self.seed)

    def reset(self) -> None:
        self.state = BotState()

    def normalize(self, record: Mapping[str, Any]) -> Dict[str, Any]:
        phrase = _first_present(record, PHRASE_FIELDS)
        raw_family = _first_present(record, FAMILY_FIELDS)
        leaf = _first_present(record, LEAF_FIELDS)
        axes = _first_axes(record)
        family = canonical_family(raw_family, phrase=phrase, axes=axes)
        return {
            "tick": _tick(record),
            "phrase": phrase,
            "family": family,
            "leaf": leaf,
            "axes": axes,
        }

    def _query_terms(self, norm: Mapping[str, Any]) -> List[str]:
        phrase = str(norm.get("phrase", ""))
        family = str(norm.get("family", "unknown"))
        leaf = str(norm.get("leaf", ""))
        axes = [str(x) for x in norm.get("axes", []) or []]
        terms = []
        terms.extend(_tokens(phrase.replace("_", " ")))
        terms.extend([f"family:{family}"] * 8)
        terms.extend(_tokens(family.replace("_", " ")) * 3)
        if leaf:
            terms.extend([f"leaf:{leaf}"] * 4)
            terms.extend(_tokens(leaf.replace("_", " ")) * 2)
        for axis in axes:
            terms.extend([f"axis:{axis}"] * 2)
            terms.extend(_tokens(axis.replace("_", " ")))
        return terms

    def _query_vec(self, norm: Mapping[str, Any]) -> List[float]:
        vec = _vector_from_terms(self._query_terms(norm))
        if self.seed_bias_strength != 0.0:
            vec = [v + self.seed_bias_strength * b for v, b in zip(vec, self._seed_bias)]
        turn = self.state.turn_count + 1
        tick = norm.get("tick")
        jitter = _bias_vector(int(_hash_float(f"{self.seed}:{turn}:{tick}") * 1_000_000_000))
        vec = [v + self.turn_jitter_strength * j for v, j in zip(vec, jitter)]
        return _normalize(vec)

    def _score_node(self, node: ResponseNode, q: Sequence[float], family: str, leaf: str) -> float:
        score = _dot(q, node.vector)
        if node.family == family:
            score += 0.16
        if leaf and node.leaf == leaf:
            score += 0.06
        if node.leaf == "followup":
            score -= 0.25
        if node.id in self.state.history:
            newest_distance = len(self.state.history) - 1 - max(i for i, item in enumerate(self.state.history) if item == node.id)
            score -= self.repeat_penalty / float(1 + newest_distance)
        if node.id == self.state.last_response_id:
            score -= self.repeat_penalty
        if node.family == self.state.last_family and self.state.family_streak >= 2:
            score -= self.same_family_streak_penalty * min(5, self.state.family_streak - 1)
        score += (_hash_float(f"score:{self.seed}:{self.state.turn_count}:{node.id}") - 0.5) * self.turn_jitter_strength
        return float(score)

    def _choose_node(self, norm: Mapping[str, Any]) -> tuple[ResponseNode, List[tuple[ResponseNode, float]], List[str]]:
        family = str(norm.get("family", "unknown"))
        leaf = str(norm.get("leaf", ""))
        query_terms = self._query_terms(norm)
        q = self._query_vec(norm)
        scored = [(node, self._score_node(node, q, family, leaf)) for node in self.nodes.values()]
        scored.sort(key=lambda x: (-x[1], x[0].id))
        return scored[0][0], scored[:8], query_terms

    def _choose_followup(self, node: ResponseNode, score: float, tick: Optional[int]) -> tuple[Optional[ResponseNode], float, float]:
        if not node.followups:
            return None, 0.0, 1.0
        p = max(0.0, min(0.85, self.followup_probability + max(0.0, score) * 0.08))
        roll = _hash_float(f"follow:{self.seed}:{self.state.turn_count}:{tick}:{node.id}")
        if roll >= p:
            return None, p, roll
        candidates = [self.nodes[x] for x in node.followups if x in self.nodes]
        if not candidates:
            return None, p, roll
        idx = int(_hash_float(f"follow-choice:{self.seed}:{self.state.turn_count}:{tick}:{node.id}") * len(candidates))
        idx = max(0, min(len(candidates) - 1, idx))
        return candidates[idx], p, roll

    def step(self, record: Mapping[str, Any]) -> BotPacket:
        norm = self.normalize(record)
        phrase = norm["phrase"]
        family = norm["family"]
        leaf = norm["leaf"]
        tick = norm["tick"]
        uncertain = is_uncertain_phrase(phrase, family)

        if family == self.state.last_family:
            streak = self.state.family_streak + 1
        else:
            streak = 1

        node, top, query_terms = self._choose_node(norm)
        follow, follow_p, follow_roll = self._choose_followup(node, top[0][1], tick)

        self.state.turn_count += 1
        self.state.last_family = family
        self.state.family_streak = streak
        self.state.last_response_id = node.id
        self.state.last_follow_up_id = "" if follow is None else follow.id
        self.state.history.append(node.id)
        if len(self.state.history) > self.max_history:
            self.state.history = self.state.history[-self.max_history:]

        rule_id = f"graph:{node.id}:{node.action}"
        top_ids = [n.id for n, _score in top]
        top_scores = [round(float(_score), 6) for _n, _score in top]

        return BotPacket(
            tick=tick,
            input_phrase=phrase,
            input_family=family,
            input_leaf=leaf,
            reply_text=node.reply_text,
            action=node.action,
            aperture_hint=node.aperture_hint,
            stimulus_policy=node.stimulus_policy,
            reafferent_gain_hint=float(node.reafferent_gain_hint),
            state_family=family,
            state_streak=streak,
            is_uncertain=uncertain,
            rule_id=rule_id,
            prefix="",
            response_id=node.id,
            response_family=node.family,
            response_leaf=node.leaf,
            response_score=round(float(top[0][1]), 6),
            query_seed=self.seed,
            query_terms=query_terms[:32],
            top_response_ids=top_ids,
            top_response_scores=top_scores,
            follow_up_text="" if follow is None else follow.reply_text,
            follow_up_id="" if follow is None else follow.id,
            follow_up_action="" if follow is None else follow.action,
            follow_up_probability=round(float(follow_p), 6),
            follow_up_roll=round(float(follow_roll), 6),
            selection_mode="response_graph_vector_index",
        )

    def neutral_packet(self, tick: Optional[int] = None, reason: str = "lag_warmup") -> BotPacket:
        node = self.nodes.get("unknown_01") or next(iter(self.nodes.values()))
        return BotPacket(
            tick=tick,
            input_phrase="",
            input_family="unknown",
            input_leaf="",
            reply_text=f"BOT ACTION=STEADY REASON={reason}",
            action=f"steady:{reason}",
            aperture_hint=node.aperture_hint,
            stimulus_policy=node.stimulus_policy,
            reafferent_gain_hint=float(node.reafferent_gain_hint),
            state_family="unknown",
            state_streak=0,
            is_uncertain=False,
            rule_id=f"graph:unknown_01:steady:{reason}",
            response_id="unknown_01",
            response_family="unknown",
            response_leaf="steady",
            response_score=0.0,
            query_seed=self.seed,
            query_terms=[],
            top_response_ids=["unknown_01"],
            top_response_scores=[0.0],
            selection_mode="response_graph_vector_index_neutral",
        )
