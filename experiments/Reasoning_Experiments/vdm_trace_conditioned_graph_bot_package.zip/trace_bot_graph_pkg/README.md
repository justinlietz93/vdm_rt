# Trace-conditioned graph bot comparison package

This fixes the earlier canned-reply bot.

The bot is now a deterministic response graph / vector index:

```text
witness trace -> vector query -> seed-biased response node -> optional related follow-up
```

It does not repeat one fixed prose sentence for a family. It returns compact structured actuator-style messages such as:

```text
BOT ACTION=FOCUS APERTURE=NARROW SIGNAL=STEADY
BOT ACTION=CONTAIN_PRESSURE RELEASE=FALSE
BOT ACTION=COMPARE_PAIR VISIBILITY=BOTH
```

If a related follow-up fires, it is sent immediately with the first response on the next tick:

```text
bot reply BOT ACTION=...
bot followup BOT FOLLOWUP=...
```

## Run

```bash
unzip vdm_trace_conditioned_graph_bot_package.zip
cd trace_bot_graph_pkg
./setup_env.sh
./run_trace_bot_1500.sh ~/git/vdm_rt
```

Longer:

```bash
./run_trace_bot_3000.sh ~/git/vdm_rt
./run_trace_bot_5000.sh ~/git/vdm_rt
```

Manual run:

```bash
venv/bin/python tools/run_trace_conditioned_bot_suite.py \
  --reset \
  --run \
  --repo ~/git/vdm_rt \
  --suite-dir runs/trace_bot_graph_1500 \
  --ticks-total 1500 \
  --tick-print-stride 50 \
  --live-topn 2
```

## Default runs

```text
bot_matched_trace
bot_lagged_trace
bot_yoked_replay
```

Ticks reset for each run. With `--ticks-total 1500`, this is 3 separate 1500-tick runs.

## Reports

Reports land in:

```text
runs/<suite>/reports/
```

Important files:

```text
RESULTS.md
condition_summary.csv
window_summary.csv
event_translation_log.csv
bot_interaction_log.csv
topk_true_vs_emitted.csv
next_window_effects.csv
```

## Tests run before packaging

```text
PYTHONPATH=src pytest -q tests
6 passed
```

I also ran a 12-tick smoke suite against a local VDM runtime copy. All three default runs completed and reports generated.
