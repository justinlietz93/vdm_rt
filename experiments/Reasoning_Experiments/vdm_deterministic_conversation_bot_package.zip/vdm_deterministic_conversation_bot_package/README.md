# VDM Deterministic Conversation Bot

This package provides a tiny deterministic conversation surface for VDM intention-trace experiments.

It is not an LLM, not a semantic decoder, not a trainer, and not a policy learner. It maps already-computed VDM posture translations into fixed, reproducible response packets that can be returned through UTE as a damped reafferent social surface.

## Purpose

The bot gives the model a stable external conversational consequence without adding intelligence from a language model.

It answers this experimental question:

```text
If the model receives a simple deterministic response to its translated posture, does its next intention trace become more stable, more engaged, more revision-capable, or more guarded?
```

The bot is deliberately simple. The intelligence being tested should remain on the VDM side.

## What it consumes

Each input row/event may contain any of these fields:

```text
tick
phrase
family
leaf
dominant_axes
score
margin
mode
condition
```

It also accepts common translator log aliases:

```text
true_top1_phrase
true_top1_family
true_top1_leaf
true_dominant_axes
fused_phrase
fused_family
selector_phrase
selector_family
aperture_phrase
aperture_family
```

## What it emits

Each output packet contains:

```text
tick
input_phrase
input_family
reply_text
action
aperture_hint
stimulus_policy
reafferent_gain_hint
state_family
state_streak
is_uncertain
rule_id
```

The `reply_text` field is the text you would return through UTE if using the bot as reafferent output.

## Install / run

No external dependencies are required.

From the package root:

```bash
python scripts/run_bot_on_translations.py \
  --input examples/sample_translation_log.csv \
  --output /tmp/vdm_bot_replies.jsonl
```

Or as a module:

```bash
PYTHONPATH=src python -m deterministic_vdm_bot.cli \
  --input examples/sample_intent_stream.jsonl \
  --output /tmp/vdm_bot_replies.jsonl
```

Run tests:

```bash
PYTHONPATH=src python -m unittest discover tests
```

## Online runtime integration

```python
from deterministic_vdm_bot import DeterministicConversationBot

bot = DeterministicConversationBot()

packet = bot.step({
    "tick": tick,
    "phrase": true_top1_phrase,
    "family": true_top1_family,
    "leaf": true_top1_leaf,
    "dominant_axes": true_dominant_axes,
})

# Runtime decides whether/how strongly to feed this back.
# Recommended initial setting: damped UTE return only.
ute_text = packet.reply_text
log_packet = packet.to_dict()
```

## Experimental conditions

Recommended first comparison:

```text
A. no_bot
   translations are logged only

B. deterministic_bot
   bot reply_text is returned through UTE after each witness/translation

C. shifted_bot
   same deterministic bot, but reply packets are delayed by a fixed lag
   example: emit the reply from 50 witness events ago

D. anti_bot_optional
   bot receives true trace, but emitted phrase is anti/mismatched by separate anti policy
```

The important comparison is between B and C:

```text
same reply distribution
same deterministic rules
wrong timing in shifted condition
```

That tests whether timing alignment matters without changing the bot's language inventory.

## CLI lag control

The CLI includes a simple event-lag mode:

```bash
PYTHONPATH=src python -m deterministic_vdm_bot.cli \
  --input event_translation_log.csv \
  --output shifted_bot_lag50.jsonl \
  --lag-events 50
```

For the first 50 rows, it emits a neutral hold packet. After that, it emits the reply that would have been produced 50 events earlier.

## Design rules

```text
No ML model.
No randomness.
No embeddings.
No training.
No prompt calls.
No hidden state beyond deterministic counters.
No semantic expansion beyond fixed rules.
```

## Recommended UTE text policy

Use the `reply_text` verbatim at first. Keep gain low.

Recommended starting gain:

```text
0.18 to 0.25
```

Do not add extra paraphrasing in the runtime loop. That would turn the bot into a moving experimental variable.

## Notes

This bot is intentionally boring. If it feels too smart, simplify the rules. Its purpose is not to impress the user. Its purpose is to provide a stable social/reafferent boundary that VDM can push against.
